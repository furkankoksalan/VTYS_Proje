import React, { useEffect, useMemo, useRef, useState } from "react";



const API_BASE = "http://127.0.0.1:8000";

const NAVY = "#184B97";
const NAVY_DARK = "#123E7F";
const BG = "#EEF3F8";

const css = `
html, body, #root { height:100%; width:100%; margin:0; }
#root{ max-width:none !important; padding:0 !important; }
body{ overflow-x:hidden; }

  *{ box-sizing:border-box; }
  html,body{ height:100%; }
  body{
    margin:0;
    font-family: Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Arial, sans-serif;
    background:${BG};
    color:#0f172a;
  }

  .app{ min-height:100vh; width:100%; }

  .shell{
    display:grid;
    grid-template-columns: 280px 1fr;
    min-height:100vh;
    width:100%;
  }

  /* Sol menü */
  .sidebar{
    background: linear-gradient(180deg, ${NAVY}, ${NAVY_DARK});
    padding:18px 16px;
    position:sticky;
    top:0;
    height:100vh;
  }
  .brand{ display:flex; align-items:center; gap:12px; margin-bottom:18px; }
  .brandMark{
    width:64px; height:44px; border-radius:10px;
    background:rgba(255,255,255,.18);
    display:flex; align-items:center; justify-content:center;
    color:#fff; font-weight:900; letter-spacing:.6px; font-size:16px;
    box-shadow: inset 0 0 0 1px rgba(255,255,255,.15);
  }
  .brandText{ color:#fff; min-width:0; }
  .brandText .title{ font-weight:900; font-size:14px; letter-spacing:.2px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .brandText .sub{ font-size:12px; opacity:.85; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

  .sideNav{ display:flex; flex-direction:column; gap:10px; margin-top:16px; }
  .sideItem{
    width:100%;
    text-align:left;
    border:none;
    cursor:pointer;
    padding:14px 14px;
    border-radius:14px;
    background:rgba(255,255,255,.10);
    color:#fff;
    font-weight:800;
    display:flex;
    align-items:center;
    gap:10px;
    box-shadow: inset 0 0 0 1px rgba(255,255,255,.10);
  }
  .sideItem:hover{ background:rgba(255,255,255,.14); }
  .sideItem.active{ background:rgba(255,255,255,.20); box-shadow: inset 0 0 0 1px rgba(255,255,255,.18); }
  .sideItem .ic{
    width:22px; height:22px; border-radius:8px;
    background:rgba(255,255,255,.18);
    display:flex; align-items:center; justify-content:center; font-size:12px;
  }

  .sideFooter{
    position:absolute; left:16px; right:16px; bottom:14px;
    color:rgba(255,255,255,.88);
    font-size:12px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:10px;
  }
  .sideFooter .user{ min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
  .dot{ width:8px; height:8px; border-radius:999px; background:#22c55e; box-shadow:0 0 0 4px rgba(34,197,94,.18); }

  /* Ana alan */
  .main{
    display:flex;
    flex-direction:column;
    min-height:100vh;
    min-width:0;
    width:100%;
  }

  /* Üst bar */
  .topbar{
    background:${NAVY};
    padding:12px 18px;
    position:sticky;
    top:0;
    z-index:10;
    box-shadow: 0 4px 18px rgba(2,6,23,.12);
    width:100%;
  }
  .topInner{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    width:100%;
    min-width:0;
  }
  .crumbs{ display:flex; align-items:center; gap:10px; min-width:0; }
  .pill{
    height:34px;
    padding:0 14px;
    border-radius:999px;
    display:inline-flex;
    align-items:center;
    gap:8px;
    border:1px solid rgba(255,255,255,.22);
    color:#fff;
    background:rgba(255,255,255,.10);
    font-weight:900;
    font-size:13px;
    min-width:0;
  }
  .pill .mini{ font-weight:900; opacity:.92; }
  .pill .truncate{ min-width:0; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

  .topActions{
    display:flex;
    align-items:center;
    gap:10px;
    flex-wrap:wrap;
    justify-content:flex-end;
    min-width:0;
  }
  .topLink{
    height:34px;
    padding:0 14px;
    border-radius:999px;
    border:1px solid rgba(255,255,255,.22);
    background:rgba(255,255,255,.08);
    color:#fff;
    font-weight:900;
    cursor:pointer;
    white-space:nowrap;
  }
  .topLink:hover{ background:rgba(255,255,255,.12); }
  .topDanger{ background:#ef4444; border-color:rgba(0,0,0,.08); }
  .topDanger:hover{ background:#dc2626; }

  /* İçerik */
  .content{
    flex:1;
    padding:18px;
    display:flex;
    flex-direction:column;
    align-items:stretch;
    gap:18px;
    min-height:0;
    width:100%;
    min-width:0;
  }

  .card{
    width:100%;
    background:#fff;
    border-radius:18px;
    box-shadow: 0 10px 26px rgba(2,6,23,.10);
    border:1px solid rgba(15,23,42,.06);
  }

  .section{ padding:18px 18px; }
  .sectionTitle{ font-weight:900; color:#0f172a; margin:0 0 12px; }
  .muted{ color:#64748b; font-size:12px; }

  .hero{ padding:22px 22px; }
  .heroTitle{ margin:0; font-size:28px; letter-spacing:-.3px; }
  .heroDesc{ margin:10px 0 0; color:#475569; line-height:1.5; font-size:14px; }
  .heroRow{ margin-top:16px; display:flex; align-items:center; gap:10px; flex-wrap:wrap; }

  /* Butonlar */
  .btn{
    height:40px;
    padding:0 16px;
    border-radius:12px;
    border:none;
    cursor:pointer;
    font-weight:900;
    letter-spacing:.2px;
  }
  .btnPrimary{ background:${NAVY}; color:#fff; box-shadow: 0 10px 18px rgba(24,75,151,.22); }
  .btnPrimary:hover{ background:${NAVY_DARK}; }
  .btnGhost{ background:rgba(24,75,151,.10); color:${NAVY_DARK}; }
  .btnGhost:hover{ background:rgba(24,75,151,.14); }
  .btnDanger{
    background:rgba(239,68,68,.10);
    color:#b91c1c;
    border:1px solid rgba(239,68,68,.22);
  }
  .btnDanger:hover{ background:rgba(239,68,68,.14); }

  /* Form */
  .grid2{
    display:grid;
    grid-template-columns: 1.1fr .9fr;
    gap:16px;
    align-items:stretch;
    width:100%;
    min-width:0;
  }
  .gridChat{
    display:grid;
    grid-template-columns: 360px 1fr;
    gap:16px;
    align-items:stretch;
    width:100%;
    min-width:0;
  }
  .formRow{ display:grid; grid-template-columns: 1fr 1fr; gap:10px; }
  .field{ display:flex; flex-direction:column; gap:6px; margin-bottom:10px; }
  .lab{ font-size:12px; color:#334155; font-weight:900; }
  .input, select, textarea{
    border:1px solid rgba(15,23,42,.10);
    border-radius:12px;
    padding:10px 10px;
    font-size:13px;
    outline:none;
  }
  .input:focus, select:focus, textarea:focus{
    box-shadow:0 0 0 4px rgba(24,75,151,.12);
    border-color: rgba(24,75,151,.35);
  }
  textarea{ resize:vertical; min-height:84px; }

  .splitLine{ height:1px; background:rgba(15,23,42,.08); margin:12px 0; }

  /* Kart öğeleri */
  .list{ display:flex; flex-direction:column; gap:10px; margin-top:12px; }
  .item{
    padding:12px;
    border:1px solid rgba(15,23,42,.08);
    border-radius:16px;
    background:#fff;
    box-shadow:0 10px 22px rgba(2,6,23,.06);
  }
  .itemTop{ display:flex; align-items:flex-start; justify-content:space-between; gap:10px; }
  .itemTitle{ font-weight:900; }
  .itemMeta{ margin-top:6px; font-size:12px; color:#64748b; line-height:1.5; }
  .itemBtns{ margin-top:12px; display:flex; gap:10px; flex-wrap:wrap; }

  .badge{
    padding:6px 10px;
    border-radius:999px;
    font-size:12px;
    font-weight:900;
    border:1px solid rgba(15,23,42,.10);
    background:rgba(24,75,151,.08);
    color:${NAVY_DARK};
    white-space:nowrap;
  }
  .badgeKayıp{
    background:rgba(239,68,68,.10);
    border-color:rgba(239,68,68,.18);
    color:#b91c1c;
  }
  .badgeBulundu{
    background:rgba(34,197,94,.10);
    border-color:rgba(34,197,94,.18);
    color:#15803d;
  }

  .toggleRow{ display:flex; gap:8px; flex-wrap:wrap; }
  .toggleBtn{
    height:34px;
    padding:0 14px;
    border-radius:999px;
    border:1px solid rgba(15,23,42,.10);
    background:#fff;
    color:#0f172a;
    font-weight:900;
    cursor:pointer;
  }
  .toggleBtn.active{
    background:rgba(24,75,151,.10);
    border-color:rgba(24,75,151,.22);
    color:${NAVY_DARK};
  }

  .centerWrap{
    min-height:calc(100vh - 56px);
    display:flex;
    align-items:center;
    justify-content:center;
    padding:18px;
  }

  /* Chat */
  .chatWrap{
    height: calc(100vh - 56px - 36px - 24px);
    min-height: 520px;
    display:flex;
    flex-direction:column;
    overflow:hidden;
  }
  .chatList{
    height: calc(100vh - 56px - 36px - 24px);
    min-height: 520px;
    overflow:auto;
  }
  .chatMessages{
    flex:1;
    overflow:auto;
    padding:12px;
    background: rgba(24,75,151,.04);
    border-radius:16px;
    border:1px solid rgba(15,23,42,.06);
  }
  .msgRow{
    display:flex;
    margin:10px 0;
  }
  .msgBubble{
    max-width: 72%;
    padding:10px 12px;
    border-radius:14px;
    border:1px solid rgba(15,23,42,.08);
    background:#fff;
    box-shadow: 0 10px 18px rgba(2,6,23,.06);
  }
  .msgMe{ justify-content:flex-end; }
  .msgMe .msgBubble{
    background: rgba(24,75,151,.10);
    border-color: rgba(24,75,151,.18);
  }
  .msgMeta{
    margin-top:6px;
    font-size:11px;
    color:#64748b;
    display:flex;
    gap:8px;
    align-items:center;
  }
  .chatComposer{
    margin-top:12px;
    display:flex;
    gap:10px;
    align-items:flex-end;
  }
  .chatComposer textarea{
    flex:1;
    min-height:44px;
    max-height:120px;
    resize:vertical;
  }

  /* Fotoğraf küçük önizleme */
  .thumbRow{ display:flex; gap:10px; flex-wrap:wrap; margin-top:10px; }
  .thumb{
    width:74px; height:74px;
    border-radius:12px;
    border:1px solid rgba(15,23,42,.10);
    background:#fff;
    overflow:hidden;
    display:flex;
    align-items:center;
    justify-content:center;
  }
  .thumb img{ width:100%; height:100%; object-fit:cover; display:block; }

  @media (max-width: 1100px){
    .gridChat{ grid-template-columns: 1fr; }
    .chatWrap, .chatList{ height:auto; min-height:auto; }
  }
  @media (max-width: 1060px){
    .shell{ grid-template-columns: 1fr; }
    .sidebar{ position:relative; height:auto; }
    .sideFooter{ position:relative; left:0; right:0; bottom:0; margin-top:12px; }
  }
  @media (max-width: 980px){
    .grid2{ grid-template-columns:1fr; }
  }
`;

function safeJsonParse(raw, fallback) {
  try {
    return raw ? JSON.parse(raw) : fallback;
  } catch {
    return fallback;
  }
}

function findName(list, idKey, id, nameKey = "name") {
  const x = (list || []).find((t) => String(t[idKey]) === String(id));
  return x ? x[nameKey] : "—";
}

function addrLabelPretty(a) {
  const bits = [
    a.address_label ? a.address_label : null,
    a.street ? a.street : null,
    a.building_no ? `No:${a.building_no}` : null,
    a.apartment_no ? `D:${a.apartment_no}` : null,
  ].filter(Boolean);
  return bits.join(" • ") || "Adres";
}

// ---------- API helpers ----------
async function apiGet(path) {
  const res = await fetch(API_BASE + path);
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  if (!res.ok) throw new Error((data && data.detail) ? data.detail : `HTTP ${res.status}`);
  return data;
}
async function apiSend(path, method, bodyObj) {
  const res = await fetch(API_BASE + path, {
    method,
    headers: { "Content-Type": "application/json; charset=utf-8" },
    body: bodyObj ? JSON.stringify(bodyObj) : undefined,
  });
  const text = await res.text();
  let data;
  try { data = JSON.parse(text); } catch { data = text; }
  if (!res.ok) throw new Error((data && data.detail) ? data.detail : `HTTP ${res.status}`);
  return data;
}

const LS_SESSION = "lostpet_session_api_v1";

export default function App() {
  const [clock, setClock] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // Session
  const [session, setSession] = useState(() =>
    safeJsonParse(localStorage.getItem(LS_SESSION), {
      isAuthed: false,
      user: null, 
    })
  );
  useEffect(() => localStorage.setItem(LS_SESSION, JSON.stringify(session)), [session]);

  const authedUser = session.isAuthed ? session.user : null;

  const [LOOKUP, setLOOKUP] = useState({
    countries: [],
    cities: [],
    districts: [],
    neighborhoods: [],
    species: [],
    colors: [],
  });

  // Domain data (DB)
  const [myAddresses, setMyAddresses] = useState([]);
  const [myPets, setMyPets] = useState([]);
  const [listings, setListings] = useState([]);
  const [listingPhotosCache, setListingPhotosCache] = useState({}); 
  const [conversations, setConversations] = useState([]); 
  const [participantsCache, setParticipantsCache] = useState({});
  const [messagesCache, setMessagesCache] = useState({});
  const [addressTextCache, setAddressTextCache] = useState({}); 


  const [globalError, setGlobalError] = useState("");
  const [busy, setBusy] = useState(false);

  // Navigation
  const [page, setPage] = useState("anasayfa");
  const [top, setTop] = useState("Ana Sayfa");

  const setNav = (k) => {
    setPage(k);
    if (k === "anasayfa") setTop("Ana Sayfa");
    if (k === "kesfet") setTop("Keşfet");
    if (k === "ilan") setTop("İlan Oluştur");
    if (k === "adresler") setTop("Adreslerim");
    if (k === "evcil") setTop("Evcil Hayvanlarım");
    if (k === "eslesmeler") setTop("Eşleşmeler");
    if (k === "mesajlar") setTop("Mesajlar");
    if (k === "profil") setTop("Profil");
  };

  const logout = () => {
    setSession({ isAuthed: false, user: null });
    setNav("anasayfa");
  };

  // -------- Load lookups once --------
  useEffect(() => {
    (async () => {
      try {
        const [countries, species, colors] = await Promise.all([
          apiGet("/lookups/countries?limit=300"),
          apiGet("/lookups/species?limit=300"),
          apiGet("/lookups/colors?limit=2000"),
        ]);

        // Cities/districts/neighborhoods: lazy (selected by user) OR pull max (senin backend limit çok yüksek)
        // Burada şehirleri TR için çekiyoruz (ülke id = 1 diye varsaymıyoruz; kullanıcı seçim yaptıkça çekeriz)
        setLOOKUP((p) => ({
          ...p,
          countries: Array.isArray(countries) ? countries : [],
          species: Array.isArray(species) ? species : [],
          colors: Array.isArray(colors) ? colors : [],
        }));
      } catch (e) {
        setGlobalError(String(e?.message || e));
      }
    })();
  }, []);


  
  // -------- Load user-bound data when logged in --------
  const refreshAll = async () => {
    if (!authedUser?.user_id) return;
    setGlobalError("");
    try {
      const [addresses, pets, listingsRes, convs] = await Promise.all([
        apiGet(`/users/${authedUser.user_id}/addresses`),
        apiGet(`/users/${authedUser.user_id}/pets`),
        apiGet(`/listings?limit=200&offset=0`),
        apiGet(`/users/${authedUser.user_id}/conversations?limit=200`),
      ]);
      setMyAddresses(Array.isArray(addresses) ? addresses : []);
      setMyPets(Array.isArray(pets) ? pets : []);
      setListings(Array.isArray(listingsRes) ? listingsRes : []);
      setConversations(Array.isArray(convs) ? convs : []);
    } catch (e) {
      setGlobalError(String(e?.message || e));
    }
  };

  useEffect(() => {
    if (authedUser?.user_id) refreshAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authedUser?.user_id]);

  // ---------- Auth ----------
  const [authTab, setAuthTab] = useState("giris");
  const [loginForm, setLoginForm] = useState({ email: "", password: "" });
  const [regForm, setRegForm] = useState({
    full_name: "",
    email: "",
    phone: "",
    password: "",
    password2: "",
  });

  const doRegister = async () => {
    const full_name = regForm.full_name.trim();
    const email = regForm.email.trim().toLowerCase();
    const phone = regForm.phone.trim();
    const pw = regForm.password;
    const pw2 = regForm.password2;

    if (!full_name) return alert("Ad Soyad zorunlu.");
    if (!email) return alert("E-posta zorunlu.");
    if (!pw || pw.length < 4) return alert("Şifre en az 4 karakter olmalı.");
    if (pw !== pw2) return alert("Şifreler eşleşmiyor.");

    setBusy(true);
    setGlobalError("");
    try {
      const u = await apiSend("/auth/register", "POST", {
        full_name,
        email,
        phone: phone || null,
        password: pw,
      });
      setSession({ isAuthed: true, user: u });
      setRegForm({ full_name: "", email: "", phone: "", password: "", password2: "" });
      setAuthTab("giris");
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  const doLogin = async () => {
    const email = loginForm.email.trim().toLowerCase();
    const pw = loginForm.password;

    if (!email) return alert("E-posta zorunlu.");
    if (!pw) return alert("Şifre zorunlu.");

    setBusy(true);
    setGlobalError("");
    try {
      const u = await apiSend("/auth/login", "POST", { email, password: pw });
      setSession({ isAuthed: true, user: u });
      setLoginForm({ email: "", password: "" });
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  // ---------- Helpers ----------
  const primaryAddr = useMemo(() => {
    if (!authedUser?.primary_address_id) return null;
    return myAddresses.find((a) => String(a.address_id) === String(authedUser.primary_address_id)) || null;
  }, [authedUser, myAddresses]);

  const listingAddressText = async (address_id) => {
    try {
      const a = await apiGet(`/addresses/${address_id}`);
      return a?.display_text || a?.label || "—";
    } catch {
      return "—";
    }
  };

const ensureAddressText = async (address_id) => {
  if (!address_id) return "—";
  if (addressTextCache[address_id]) return addressTextCache[address_id];

  try {
    const a = await apiGet(`/addresses/${address_id}`);

    const text =
      a?.display_text ||
      a?.location_text ||
      a?.label ||
      [
        a?.neighborhood_name,
        a?.district_name,
        a?.city_name,
      ].filter(Boolean).join(", ") ||
      "—";

    setAddressTextCache((p) => ({ ...p, [address_id]: text }));
    return text;
  } catch {
    setAddressTextCache((p) => ({ ...p, [address_id]: "—" }));
    return "—";
  }
};


  // ---------- Addresses ----------
  const emptyAddressForm = {
    address_label: "",
    country_id: "",
    city_id: "",
    district_id: "",
    neighborhood_id: "",
    street: "",
    building_no: "",
    apartment_no: "",
    postal_code: "",
    is_default: false,
  };
  const [addrForm, setAddrForm] = useState(emptyAddressForm);

  const countries = LOOKUP.countries || [];
  const citiesForCountry = useMemo(
    () => (LOOKUP.cities || []).filter((c) => String(c.country_id) === String(addrForm.country_id)),
    [LOOKUP.cities, addrForm.country_id]
  );
  const districtsForCity = useMemo(
    () => (LOOKUP.districts || []).filter((d) => String(d.city_id) === String(addrForm.city_id)),
    [LOOKUP.districts, addrForm.city_id]
  );
  const neighborhoodsForDistrict = useMemo(
    () => (LOOKUP.neighborhoods || []).filter((n) => String(n.district_id) === String(addrForm.district_id)),
    [LOOKUP.neighborhoods, addrForm.district_id]
  );

  // lazy load cities/districts/neighborhoods
  useEffect(() => {
    (async () => {
      if (!addrForm.country_id) return;
      try {
        const cities = await apiGet(`/lookups/cities?country_id=${encodeURIComponent(addrForm.country_id)}&limit=5000`);
        setLOOKUP((p) => ({ ...p, cities: Array.isArray(cities) ? cities : [] }));
      } catch {}
    })();
  }, [addrForm.country_id]);

  useEffect(() => {
    (async () => {
      if (!addrForm.city_id) return;
      try {
        const districts = await apiGet(`/lookups/districts?city_id=${encodeURIComponent(addrForm.city_id)}&limit=20000`);
        setLOOKUP((p) => ({ ...p, districts: Array.isArray(districts) ? districts : [] }));
      } catch {}
    })();
  }, [addrForm.city_id]);

  useEffect(() => {
    (async () => {
      if (!addrForm.district_id) return;
      try {
        const ns = await apiGet(`/lookups/neighborhoods?district_id=${encodeURIComponent(addrForm.district_id)}&limit=20000`);
        setLOOKUP((p) => ({ ...p, neighborhoods: Array.isArray(ns) ? ns : [] }));
      } catch {}
    })();
  }, [addrForm.district_id]);

  const addAddress = async () => {
    if (!authedUser) return;
    if (!addrForm.address_label.trim()) return alert("Adres etiketi zorunlu.");
    if (!addrForm.country_id) return alert("Ülke seç.");
    if (!addrForm.city_id) return alert("Şehir seç.");
    if (!addrForm.district_id) return alert("İlçe seç.");
    if (!addrForm.neighborhood_id) return alert("Mahalle seç.");

    setBusy(true);
    try {
      const res = await apiSend("/addresses", "POST", {
        user_id: authedUser.user_id,
        country_id: addrForm.country_id,
        city_id: addrForm.city_id,
        district_id: addrForm.district_id,
        neighborhood_id: addrForm.neighborhood_id,
        address_label: addrForm.address_label,
        street: addrForm.street || null,
        building_no: addrForm.building_no || null,
        apartment_no: addrForm.apartment_no || null,
        postal_code: addrForm.postal_code || null,
        is_default: !!addrForm.is_default,
      });

      if (addrForm.is_default) {
        // Session user update (backend userOut does include primary_address_id; but endpoint returns only {address_id})
        setSession((p) => ({
          ...p,
          user: { ...p.user, primary_address_id: res.address_id },
        }));
      } else if (!authedUser.primary_address_id) {
        // ilk adres ise primary yap (UI kolaylığı)
        await apiSend("/users/primary-address", "POST", { user_id: authedUser.user_id, address_id: res.address_id });
        setSession((p) => ({
          ...p,
          user: { ...p.user, primary_address_id: res.address_id },
        }));
      }

      await refreshAll();
      setAddrForm((p) => ({ ...emptyAddressForm, country_id: p.country_id || "" }));
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  const deleteAddress = async (address_id) => {
    if (!authedUser) return;
    if (!confirm("Bu adres silinsin mi?")) return;
    setBusy(true);
    try {
      await apiSend(`/users/${authedUser.user_id}/addresses/${address_id}`, "DELETE");
      if (String(authedUser.primary_address_id) === String(address_id)) {
        setSession((p) => ({ ...p, user: { ...p.user, primary_address_id: null } }));
      }
      await refreshAll();
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  const setPrimaryAddress = async (address_id) => {
    if (!authedUser) return;
    setBusy(true);
    try {
      await apiSend("/users/primary-address", "POST", { user_id: authedUser.user_id, address_id });
      setSession((p) => ({ ...p, user: { ...p.user, primary_address_id: address_id } }));
      await refreshAll();
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  // ---------- Pets ----------
  const emptyPetForm = {
    name: "",
    species_id: "",
    sex: "bilinmiyor",
    age_years: "",
    microchip_no: "",
    distinctive_marks: "",
    color_ids: [],
  };
  const [petForm, setPetForm] = useState(emptyPetForm);

  const togglePetColor = (color_id) => {
    setPetForm((p) => {
      const set = new Set(p.color_ids);
      if (set.has(color_id)) set.delete(color_id);
      else set.add(color_id);
      return { ...p, color_ids: Array.from(set) };
    });
  };

  const addPet = async () => {
    if (!authedUser) return;
    if (!petForm.species_id) return alert("Tür seç.");

    setBusy(true);
    try {
      await apiSend("/pets", "POST", {
        owner_user_id: authedUser.user_id,
        species_id: petForm.species_id,
        name: petForm.name || null,
        sex: petForm.sex,
        age_years: petForm.age_years ? Number(petForm.age_years) : null,
        microchip_no: petForm.microchip_no || null,
        distinctive_marks: petForm.distinctive_marks || null,
        color_ids: petForm.color_ids || [],
      });
      setPetForm(emptyPetForm);
      await refreshAll();
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  const deletePet = async (pet_id) => {
    if (!confirm("Evcil hayvan silinsin mi?")) return;
    setBusy(true);
    try {
      await apiSend(`/pets/${pet_id}`, "DELETE");
      await refreshAll();
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  // Pet renkleri list endpointinden gelmiyor; ama senin backend list_user_pets color_ids döndürüyor.
  const petColorNames = (pet) => {
    const ids = pet?.color_ids || [];
    if (!ids.length) return "—";
    return ids.map((id) => findName(LOOKUP.colors, "color_id", id)).join(", ");
  };

  // ---------- Listings + Photos ----------
  const [addressMode, setAddressMode] = useState("kayitli");
  const [selectedAddressId, setSelectedAddressId] = useState("");

  const emptyListingForm = {
    listing_type: "kayıp",
    status: "aktif",
    title: "",
    description: "",
    event_time: "",
    pet_id: "",
    address_label: "",
    country_id: "",
    city_id: "",
    district_id: "",
    neighborhood_id: "",
    street: "",
    building_no: "",
    apartment_no: "",
    postal_code: "",
    photo_items: [], 
    species_id: "",
      // [{temp_id, file_name, data_url}]
  };
  const [listingForm, setListingForm] = useState(emptyListingForm);
  const onListing = (k) => (e) => setListingForm((p) => ({ ...p, [k]: e.target.value }));

  // listing new address lookups
  const citiesForNewListing = useMemo(
    () => (LOOKUP.cities || []).filter((c) => String(c.country_id) === String(listingForm.country_id)),
    [LOOKUP.cities, listingForm.country_id]
  );
  const districtsForNewListing = useMemo(
    () => (LOOKUP.districts || []).filter((d) => String(d.city_id) === String(listingForm.city_id)),
    [LOOKUP.districts, listingForm.city_id]
  );
  const neighborhoodsForNewListing = useMemo(
    () => (LOOKUP.neighborhoods || []).filter((n) => String(n.district_id) === String(listingForm.district_id)),
    [LOOKUP.neighborhoods, listingForm.district_id]
  );

  useEffect(() => {
    (async () => {
      if (!listingForm.country_id) return;
      try {
        const cities = await apiGet(`/lookups/cities?country_id=${encodeURIComponent(listingForm.country_id)}&limit=5000`);
        setLOOKUP((p) => ({ ...p, cities: Array.isArray(cities) ? cities : [] }));
      } catch {}
    })();
  }, [listingForm.country_id]);

  useEffect(() => {
    (async () => {
      if (!listingForm.city_id) return;
      try {
        const districts = await apiGet(`/lookups/districts?city_id=${encodeURIComponent(listingForm.city_id)}&limit=20000`);
        setLOOKUP((p) => ({ ...p, districts: Array.isArray(districts) ? districts : [] }));
      } catch {}
    })();
  }, [listingForm.city_id]);

  useEffect(() => {
    (async () => {
      if (!listingForm.district_id) return;
      try {
        const ns = await apiGet(`/lookups/neighborhoods?district_id=${encodeURIComponent(listingForm.district_id)}&limit=20000`);
        setLOOKUP((p) => ({ ...p, neighborhoods: Array.isArray(ns) ? ns : [] }));
      } catch {}
    })();
  }, [listingForm.district_id]);

  // photo picker
  const fileInputRef = useRef(null);
  const openFilePicker = () => fileInputRef.current && fileInputRef.current.click();

  const readFileAsDataURL = (file) =>
    new Promise((resolve, reject) => {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result || ""));
      fr.onerror = reject;
      fr.readAsDataURL(file);
    });

  const onPickFiles = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    e.target.value = "";

    const MAX_FILES = 6;
    const remain = Math.max(0, MAX_FILES - (listingForm.photo_items?.length || 0));
    const slice = files.slice(0, remain);
    if (slice.length < files.length) alert(`En fazla ${MAX_FILES} fotoğraf ekleyebilirsin. Fazlası alınmadı.`);

    try {
      const newItems = [];
      for (const f of slice) {
        if (f.size > 2.5 * 1024 * 1024) {
          alert(`"${f.name}" dosyası çok büyük (2.5MB üstü). Daha küçük bir fotoğraf seç.`);
          continue;
        }
        const data_url = await readFileAsDataURL(f);
        newItems.push({ temp_id: crypto?.randomUUID ? crypto.randomUUID() : String(Date.now()), file_name: f.name, data_url });
      }
      if (newItems.length) setListingForm((p) => ({ ...p, photo_items: [...(p.photo_items || []), ...newItems] }));
    } catch {
      alert("Fotoğraf okunurken hata oldu. Lütfen tekrar dene.");
    }
  };

  const removePhotoItem = (temp_id) => {
    setListingForm((p) => ({ ...p, photo_items: (p.photo_items || []).filter((x) => x.temp_id !== temp_id) }));
  };

  const listingPetTitle = (pet_id) => {
    if (!pet_id) return "—";
    const p = myPets.find((x) => String(x.pet_id) === String(pet_id));
    if (!p) return "—";
    const sp = findName(LOOKUP.species, "species_id", p.species_id);
    const nm = p.name ? ` • ${p.name}` : "";
    return `${sp}${nm}`;
  };

  const ensureListingPhotos = async (listing_id) => {
    if (listingPhotosCache[listing_id]) return listingPhotosCache[listing_id];
    try {
      const photos = await apiGet(`/listings/${listing_id}/photos?include_data_url=true`);
      setListingPhotosCache((p) => ({ ...p, [listing_id]: Array.isArray(photos) ? photos : [] }));
      return Array.isArray(photos) ? photos : [];
    } catch {
      setListingPhotosCache((p) => ({ ...p, [listing_id]: [] }));
      return [];
    }
  };

  const submitListing = async () => {
    if (!authedUser) return;
    const title = listingForm.title.trim();
    if (!title) return alert("Başlık zorunlu.");

    setBusy(true);
    try {
      let address_id = null;

      if (addressMode === "kayitli") {
        if (!selectedAddressId) return alert("Kayıtlı bir adres seç.");
        address_id = selectedAddressId;
      } else {
        if (!listingForm.address_label.trim()) return alert("Adres etiketi zorunlu.");
        if (!listingForm.country_id) return alert("Ülke seç.");
        if (!listingForm.city_id) return alert("Şehir seç.");
        if (!listingForm.district_id) return alert("İlçe seç.");
        if (!listingForm.neighborhood_id) return alert("Mahalle seç.");

        const resAddr = await apiSend("/addresses", "POST", {
          user_id: authedUser.user_id,
          country_id: listingForm.country_id,
          city_id: listingForm.city_id,
          district_id: listingForm.district_id,
          neighborhood_id: listingForm.neighborhood_id,
          address_label: listingForm.address_label,
          street: listingForm.street || null,
          building_no: listingForm.building_no || null,
          apartment_no: listingForm.apartment_no || null,
          postal_code: listingForm.postal_code || null,
          is_default: false,
        });
        address_id = resAddr.address_id;

        if (!authedUser.primary_address_id) {
          await apiSend("/users/primary-address", "POST", { user_id: authedUser.user_id, address_id });
          setSession((p) => ({ ...p, user: { ...p.user, primary_address_id: address_id } }));
        }
      }

      const created = await apiSend("/listings", "POST", {
        created_by: authedUser.user_id,
        pet_id: listingForm.pet_id || null,
        address_id,
        listing_type: listingForm.listing_type,
        status: listingForm.status,
        title,
        description: listingForm.description.trim() || null,
        event_time: listingForm.event_time.trim() || null,
        species_id: listingForm.species_id || null,

      });

      const listing_id = created.listing_id;

      // Upload photos
      const items = listingForm.photo_items || [];
      for (let i = 0; i < items.length; i++) {
        const it = items[i];
        await apiSend("/listing-photos", "POST", {
          listing_id,
          file_name: it.file_name || null,
          data_url: it.data_url,
          sort_order: i,
        });
      }

      // refresh
      await refreshAll();
      await ensureListingPhotos(listing_id);

      setListingForm(emptyListingForm);
      setAddressMode("kayitli");
      setSelectedAddressId("");
      setNav("kesfet");
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  // Explore
  const [exploreSearch, setExploreSearch] = useState("");
  const [exploreType, setExploreType] = useState("hepsi");

  const filteredListings = useMemo(() => {
    const q = exploreSearch.trim().toLowerCase();
    return (listings || [])
      .filter((l) => (exploreType === "hepsi" ? true : l.listing_type === exploreType))
      .filter((l) => {
        if (!q) return true;
        const s = `${l.title} ${l.description || ""}`.toLowerCase();
        return s.includes(q);
      });
  }, [listings, exploreSearch, exploreType]);

  const markSolved = async (listing_id) => {
    setBusy(true);
    try {
      await apiSend(`/listings/${listing_id}`, "PATCH", { status: "çözüldü" });
      await refreshAll();
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  const deleteListing = async (listing_id) => {
    if (!confirm("İlan silinsin mi? (foto + konuşmalar da silinir)")) return;
    setBusy(true);
    try {
      await apiSend(`/listings/${listing_id}`, "DELETE");
      setListingPhotosCache((p) => {
        const n = { ...p };
        delete n[listing_id];
        return n;
      });
      await refreshAll();
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  useEffect(() => {
  if (page !== "kesfet") return;
  (filteredListings || []).slice(0, 100).forEach((l) => {
    if (l.address_id) ensureAddressText(l.address_id);
  });
}, [page, filteredListings]);


  // ---------- Messaging ----------
  const [activeConversationId, setActiveConversationId] = useState(null);
  const [chatDraft, setChatDraft] = useState("");

  const ensureParticipants = async (cid) => {
    if (participantsCache[cid]) return participantsCache[cid];
    try {
      const ps = await apiGet(`/conversations/${cid}/participants`);
      setParticipantsCache((p) => ({ ...p, [cid]: Array.isArray(ps) ? ps : [] }));
      return Array.isArray(ps) ? ps : [];
    } catch {
      setParticipantsCache((p) => ({ ...p, [cid]: [] }));
      return [];
    }
  };

  const ensureMessages = async (cid) => {
    if (messagesCache[cid]) return messagesCache[cid];
    try {
      const ms = await apiGet(`/conversations/${cid}/messages?limit=300`);
      setMessagesCache((p) => ({ ...p, [cid]: Array.isArray(ms) ? ms : [] }));
      return Array.isArray(ms) ? ms : [];
    } catch {
      setMessagesCache((p) => ({ ...p, [cid]: [] }));
      return [];
    }
  };

  const openOrCreateConversationForListing = async (listing) => {
    if (!authedUser) return;
    if (String(listing.created_by) === String(authedUser.user_id)) {
      alert("Bu ilan sana ait. Mesajlaşma için başka bir kullanıcıyla konuşma gerekir.");
      return;
    }
    setBusy(true);
    try {
      const res = await apiSend("/conversations/open", "POST", {
        listing_id: listing.listing_id,
        user_a: authedUser.user_id,
        user_b: listing.created_by,
      });
      const cid = res.conversation_id;
      await refreshAll(); // conv list yenilensin
      await ensureParticipants(cid);
      await ensureMessages(cid);
      setActiveConversationId(cid);
      setChatDraft("");
      setNav("mesajlar");
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  const activeConversation = useMemo(() => {
    if (!activeConversationId) return null;
    return (conversations || []).find((c) => String(c.conversation_id) === String(activeConversationId)) || null;
  }, [activeConversationId, conversations]);

  const activeMessages = useMemo(() => {
    if (!activeConversationId) return [];
    return (messagesCache[activeConversationId] || []).slice().sort((a, b) => (a.created_at || "").localeCompare(b.created_at || ""));
  }, [messagesCache, activeConversationId]);

  const getConversationTitle = (conv) => {
    const l = (listings || []).find((x) => String(x.listing_id) === String(conv.listing_id));
    return l?.title || "İlan";
  };

  const getOtherParticipantId = (cid) => {
    if (!authedUser) return null;
    const ps = participantsCache[cid] || [];
    const other = ps.map((x) => x.user_id).find((uid) => String(uid) !== String(authedUser.user_id));
    return other || null;
  };

  const sendMessage = async () => {
    if (!authedUser || !activeConversationId) return;
    const body = chatDraft.trim();
    if (!body) return;

    setBusy(true);
    try {
      await apiSend("/messages", "POST", {
        conversation_id: activeConversationId,
        sender_user_id: authedUser.user_id,
        body,
      });
      setChatDraft("");
      const ms = await apiGet(`/conversations/${activeConversationId}/messages?limit=300`);
      setMessagesCache((p) => ({ ...p, [activeConversationId]: Array.isArray(ms) ? ms : [] }));
    } catch (e) {
      alert(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  };

  const convLastMessage = (cid) => {
    const ms = (messagesCache[cid] || []).slice().sort((a, b) => (b.created_at || "").localeCompare(a.created_at || ""));
    return ms[0] || null;
  };

  useEffect(() => {
    (async () => {
      if (!activeConversationId) return;
      await ensureParticipants(activeConversationId);
      await ensureMessages(activeConversationId);
    })();
  }, [activeConversationId]);

  // ---------- Matches (backend) ----------
  const [matchesLostId, setMatchesLostId] = useState("");
  const [matchesRows, setMatchesRows] = useState([]);
  const [matchesLoading, setMatchesLoading] = useState(false);
  const [matchesErr, setMatchesErr] = useState("");

  const myActiveLostListings = useMemo(() => {
    if (!authedUser?.user_id) return [];
    return (listings || [])
      .filter((l) => String(l.created_by) === String(authedUser.user_id))
      .filter((l) => l.status === "aktif")
      .filter((l) => l.listing_type === "kayıp");
  }, [listings, authedUser?.user_id]);

  useEffect(() => {
    if (page !== "eslesmeler") return;
    if (matchesLostId) return;
    if (myActiveLostListings.length > 0) setMatchesLostId(myActiveLostListings[0].listing_id);
  }, [page, myActiveLostListings, matchesLostId]);

  const fetchMatches = async (lostId) => {
    if (!lostId) return;
    setMatchesLoading(true);
    setMatchesErr("");
    try {
      const rows = await apiGet(`/matches/${lostId}?limit=60&offset=0`);
      setMatchesRows(Array.isArray(rows) ? rows : []);
    } catch (e) {
      setMatchesRows([]);
      setMatchesErr(String(e?.message || e));
    } finally {
      setMatchesLoading(false);
    }
  };

  useEffect(() => {
    if (page !== "eslesmeler") return;
    if (!matchesLostId) return;
    fetchMatches(matchesLostId);
  }, [matchesLostId, page]);

  // ---------- UI ----------
  return (
    <div className="app">
      <style>{css}</style>

      {globalError && (
        <div style={{ padding: 12, background: "rgba(239,68,68,.12)", borderBottom: "1px solid rgba(239,68,68,.18)" }}>
          <b>Hata:</b> {globalError}
        </div>
      )}

      {/* LOGIN */}
      {!session.isAuthed && (
        <div className="centerWrap">
          <div className="card section" style={{ width: "100%", maxWidth: 760 }}>
            <h3 className="sectionTitle" style={{ marginBottom: 6 }}>
              Kayıp Evcil Hayvan Platformu
            </h3>
            <div className="muted"></div>

            <div className="splitLine" />

            <div className="toggleRow" style={{ marginBottom: 12 }}>
              <button className={`toggleBtn ${authTab === "giris" ? "active" : ""}`} onClick={() => setAuthTab("giris")} type="button">
                Giriş
              </button>
              <button className={`toggleBtn ${authTab === "kayit" ? "active" : ""}`} onClick={() => setAuthTab("kayit")} type="button">
                Kayıt Ol
              </button>
            </div>

            {authTab === "giris" ? (
              <>
                <div className="formRow">
                  <div className="field">
                    <div className="lab">E-posta</div>
                    <input className="input" value={loginForm.email} onChange={(e) => setLoginForm((p) => ({ ...p, email: e.target.value }))} placeholder="email@ornek.com" />
                  </div>
                  <div className  ="field">
                    <div className="lab">Şifre</div>
                    <input
                      className="input"
                      type="password"
                      value={loginForm.password}
                      onChange={(e) => setLoginForm((p) => ({ ...p, password: e.target.value }))}
                      placeholder="••••"
                    />
                  </div>
                </div>

                <div className="heroRow" style={{ justifyContent: "flex-end" }}>
                  <button className="btn btnPrimary" disabled={busy} onClick={doLogin} type="button">
                    {busy ? "Giriş yapılıyor..." : "Giriş Yap"}
                  </button>
                </div>
              </>
            ) : (
              <>
                <div className="formRow">
                  <div className="field">
                    <div className="lab">Ad Soyad</div>
                    <input
                      className="input"
                      value={regForm.full_name}
                      onChange={(e) => setRegForm((p) => ({ ...p, full_name: e.target.value }))}
                      placeholder="Ad Soyad"
                    />
                  </div>
                  <div className="field">
                    <div className="lab">E-posta</div>
                    <input
                      className="input"
                      value={regForm.email}
                      onChange={(e) => setRegForm((p) => ({ ...p, email: e.target.value }))}
                      placeholder="email@ornek.com"
                    />
                  </div>
                </div>

                <div className="formRow">
                  <div className="field">
                    <div className="lab">Telefon (opsiyonel)</div>
                    <input
                      className="input"
                      value={regForm.phone}
                      onChange={(e) => setRegForm((p) => ({ ...p, phone: e.target.value }))}
                      placeholder="05xx..."
                    />
                  </div>
                  <div className="field">
                    <div className="lab">Şifre</div>
                    <input
                      className="input"
                      type="password"
                      value={regForm.password}
                      onChange={(e) => setRegForm((p) => ({ ...p, password: e.target.value }))}
                      placeholder="En az 4 karakter"
                    />
                  </div>
                </div>

                <div className="formRow">
                  <div className="field">
                    <div className="lab">Şifre (tekrar)</div>
                    <input
                      className="input"
                      type="password"
                      value={regForm.password2}
                      onChange={(e) => setRegForm((p) => ({ ...p, password2: e.target.value }))}
                      placeholder="Şifreyi tekrar yaz"
                    />
                  </div>
                  <div className="field" />
                </div>

                <div className="heroRow" style={{ justifyContent: "flex-end" }}>
                  <button className="btn btnPrimary" disabled={busy} onClick={doRegister} type="button">
                    {busy ? "Kayıt yapılıyor..." : "Kayıt Ol"}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* APP */} 
      {session.isAuthed && (
        <div className="shell">
          {/* SIDEBAR */}
          <aside className="sidebar">
            <div className="brand">
              <div className="brandText">
                <div className="title">Kayıp Evcil Hayvan</div>
              </div>
            </div>

            <div className="sideNav">
              <button className={`sideItem ${page === "anasayfa" ? "active" : ""}`} onClick={() => setNav("anasayfa")} type="button">
                <span className="ic">🏠</span> Ana Sayfa
              </button>
              <button className={`sideItem ${page === "kesfet" ? "active" : ""}`} onClick={() => setNav("kesfet")} type="button">
                <span className="ic">🔎</span> Keşfet
              </button>
              <button className={`sideItem ${page === "ilan" ? "active" : ""}`} onClick={() => setNav("ilan")} type="button">
                <span className="ic">➕</span> İlan Oluştur
              </button>
              <button className={`sideItem ${page === "adresler" ? "active" : ""}`} onClick={() => setNav("adresler")} type="button">
                <span className="ic">📍</span> Adreslerim
              </button>
              <button className={`sideItem ${page === "evcil" ? "active" : ""}`} onClick={() => setNav("evcil")} type="button">
                <span className="ic">🐾</span> Evcil Hayvanlarım
              </button>
              <button className={`sideItem ${page === "mesajlar" ? "active" : ""}`} onClick={() => setNav("mesajlar")} type="button">
                <span className="ic">💬</span> Mesajlar
              </button>
              <button className={`sideItem ${page === "eslesmeler" ? "active" : ""}`} onClick={() => setNav("eslesmeler")} type="button">
                <span className="ic">🤝</span> Eşleşmeler
              </button>
              <button className={`sideItem ${page === "profil" ? "active" : ""}`} onClick={() => setNav("profil")} type="button">
                <span className="ic">👤</span> Profil
              </button>
            </div>

            <div className="sideFooter">
              <div className="user">
                <div style={{ fontWeight: 900, fontSize: 12, lineHeight: 1.2 }}>
                  {authedUser?.full_name || `Kullanıcı: ${authedUser?.user_id}`}
                </div>
                <div style={{ opacity: 0.85, marginTop: 2 }}>
                  {clock.toLocaleTimeString("tr-TR")}
                </div>
              </div>
              <div className="dot" title="Online" />
            </div>
          </aside>

          {/* MAIN */}
          <main className="main">
            {/* TOPBAR */}
            <div className="topbar">
              <div className="topInner">
                <div className="crumbs">
                  <div className="pill">
                    <span className="mini">📌</span>
                    <span className="truncate">{top}</span>
                  </div>
                  {primaryAddr && (
                    <div className="pill" title={addrLabelPretty(primaryAddr)}>
                      <span className="mini">🏷️</span>
                      <span className="truncate">{addrLabelPretty(primaryAddr)}</span>
                    </div>
                  )}
                </div>

                <div className="topActions">
                  <button className="topLink" onClick={refreshAll} disabled={busy} type="button">
                    {busy ? "Yükleniyor..." : "Yenile"}
                  </button>
                  <button className="topLink topDanger" onClick={logout} type="button">
                    Çıkış
                  </button>
                </div>
              </div>
            </div>

            {/* CONTENT */}
            <div className="content">
              {/* ANA SAYFA */}
              {page === "anasayfa" && (
                <div className="card hero">
                  <h1 className="heroTitle">Hoş geldin 👋</h1>
                  <p className="heroDesc">
                    Bu arayüz FastAPI backend ile çalışır. Adres ekleyebilir, evcil hayvanlarını kaydedebilir,
                    ilan oluşturabilir ve ilan sahipleriyle mesajlaşabilirsin.
                  </p>

                  <div className="heroRow">
                    <span className="badge">Adres: {myAddresses.length}</span>
                    <span className="badge">Evcil: {myPets.length}</span>
                    <span className="badge">İlan: {listings.length}</span>
                    <span className="badge">Konuşma: {conversations.length}</span>
                  </div>

                  <div className="heroRow">
                    <button className="btn btnPrimary" onClick={() => setNav("ilan")} type="button">
                      İlan Oluştur
                    </button>
                    <button className="btn btnGhost" onClick={() => setNav("kesfet")} type="button">
                      İlanlara Göz At
                    </button>
                    <button className="btn btnGhost" onClick={() => setNav("mesajlar")} type="button">
                      Mesajlara Git
                    </button>
                  </div>
                </div>
              )}

              {/* ADRESLER */}
              {page === "adresler" && (
                <div className="grid2">
                  <div className="card section">
                    <h3 className="sectionTitle">Adres Ekle</h3>
                    <div className="splitLine" />

                    <div className="field">
                      <div className="lab">Adres Etiketi</div>
                      <input className="input" value={addrForm.address_label} onChange={(e) => setAddrForm((p) => ({ ...p, address_label: e.target.value }))} placeholder="Ev / İş / Anne evi..." />
                    </div>

                    <div className="formRow">
                      <div className="field">
                        <div className="lab">Ülke</div>
                        <select className="input" value={addrForm.country_id} onChange={(e) => setAddrForm((p) => ({ ...p, country_id: e.target.value, city_id: "", district_id: "", neighborhood_id: "" }))}>
                          <option value="">Seç</option>
                          {countries.map((c) => (
                            <option key={c.country_id} value={c.country_id}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="field">
                        <div className="lab">Şehir</div>
                        <select className="input" value={addrForm.city_id} onChange={(e) => setAddrForm((p) => ({ ...p, city_id: e.target.value, district_id: "", neighborhood_id: "" }))}>
                          <option value="">Seç</option>
                          {citiesForCountry.map((c) => (
                            <option key={c.city_id} value={c.city_id}>
                              {c.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="formRow">
                      <div className="field">
                        <div className="lab">İlçe</div>
                        <select className="input" value={addrForm.district_id} onChange={(e) => setAddrForm((p) => ({ ...p, district_id: e.target.value, neighborhood_id: "" }))}>
                          <option value="">Seç</option>
                          {districtsForCity.map((d) => (
                            <option key={d.district_id} value={d.district_id}>
                              {d.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="field">
                        <div className="lab">Mahalle</div>
                        <select className="input" value={addrForm.neighborhood_id} onChange={(e) => setAddrForm((p) => ({ ...p, neighborhood_id: e.target.value }))}>
                          <option value="">Seç</option>
                          {neighborhoodsForDistrict.map((n) => (
                            <option key={n.neighborhood_id} value={n.neighborhood_id}>
                              {n.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="formRow">
                      <div className="field">
                        <div className="lab">Sokak (ops.)</div>
                        <input className="input" value={addrForm.street} onChange={(e) => setAddrForm((p) => ({ ...p, street: e.target.value }))} placeholder="Sokak" />
                      </div>
                      <div className="field">
                        <div className="lab">Bina No (ops.)</div>
                        <input className="input" value={addrForm.building_no} onChange={(e) => setAddrForm((p) => ({ ...p, building_no: e.target.value }))} placeholder="12" />
                      </div>
                    </div>

                    <div className="formRow">
                      <div className="field">
                        <div className="lab">Daire No (ops.)</div>
                        <input className="input" value={addrForm.apartment_no} onChange={(e) => setAddrForm((p) => ({ ...p, apartment_no: e.target.value }))} placeholder="5" />
                      </div>
                      <div className="field">
                        <div className="lab">Posta Kodu (ops.)</div>
                        <input className="input" value={addrForm.postal_code} onChange={(e) => setAddrForm((p) => ({ ...p, postal_code: e.target.value }))} placeholder="34xxx" />
                      </div>
                    </div>

                    <div className="toggleRow" style={{ marginTop: 6 }}>
                      <button
                        className={`toggleBtn ${addrForm.is_default ? "active" : ""}`}
                        onClick={() => setAddrForm((p) => ({ ...p, is_default: !p.is_default }))}
                        type="button"
                      >
                        ⭐ Birincil adres yap
                      </button>
                    </div>

                    <div className="heroRow" style={{ justifyContent: "flex-end" }}>
                      <button className="btn btnPrimary" disabled={busy} onClick={addAddress} type="button">
                        {busy ? "Ekleniyor..." : "Adresi Kaydet"}
                      </button>
                    </div>
                  </div>

                  <div className="card section">
                    <h3 className="sectionTitle">Adreslerim</h3>
                    <div className="muted">Birincil adres üst barda etiket olarak görünür.</div>
                    <div className="splitLine" />

                    <div className="list">
                      {myAddresses.length === 0 && <div className="muted">Henüz adres yok.</div>}
                      {myAddresses.map((a) => {
                        const isPrimary = String(a.address_id) === String(authedUser?.primary_address_id || "");
                        return (
                          <div className="item" key={a.address_id}>
                            <div className="itemTop">
                              <div>
                                <div className="itemTitle">
                                  {addrLabelPretty(a)} {isPrimary && <span className="badge">Birincil</span>}
                                </div>
                                <div className="itemMeta">
                                  Ülke: {findName(LOOKUP.countries, "country_id", a.country_id)} • Şehir:{" "}
                                  {findName(LOOKUP.cities, "city_id", a.city_id)} • İlçe: {findName(LOOKUP.districts, "district_id", a.district_id)} • Mahalle:{" "}
                                  {findName(LOOKUP.neighborhoods, "neighborhood_id", a.neighborhood_id)}
                                </div>
                              </div>
                            </div>

                            <div className="itemBtns">
                              <button className="btn btnGhost" onClick={() => setPrimaryAddress(a.address_id)} disabled={busy} type="button">
                                Birincil Yap
                              </button>
                              <button className="btn btnDanger" onClick={() => deleteAddress(a.address_id)} disabled={busy} type="button">
                                Sil
                              </button>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* EVCİL HAYVANLAR */}
              {page === "evcil" && (
                <div className="grid2">
                  <div className="card section">
                    <h3 className="sectionTitle">Evcil Hayvan Ekle</h3>
                    <div className="muted">Evcil hayvanlar DB’de tutulur. </div>
                    <div className="splitLine" />

                    <div className="formRow">
                      <div className="field">
                        <div className="lab">Tür</div>
                        <select className="input" value={petForm.species_id} onChange={(e) => setPetForm((p) => ({ ...p, species_id: e.target.value }))}>
                          <option value="">Seç</option>
                          {(LOOKUP.species || []).map((s) => (
                            <option key={s.species_id} value={s.species_id}>
                              {s.name}
                            </option>
                          ))}
                        </select>
                      </div>
                      <div className="field">
                        <div className="lab">İsim (ops.)</div>
                        <input className="input" value={petForm.name} onChange={(e) => setPetForm((p) => ({ ...p, name: e.target.value }))} placeholder="Pamuk" />
                      </div>
                    </div>

                    <div className="formRow">
                      <div className="field">
                        <div className="lab">Cinsiyet</div>
                        <select className="input" value={petForm.sex} onChange={(e) => setPetForm((p) => ({ ...p, sex: e.target.value }))}>
                          <option value="bilinmiyor">Bilinmiyor</option>
                          <option value="dişi">Dişi</option>
                          <option value="erkek">Erkek</option>
                        </select>
                      </div>
                      <div className="field">
                        <div className="lab">Yaş (ops.)</div>
                        <input className="input" value={petForm.age_years} onChange={(e) => setPetForm((p) => ({ ...p, age_years: e.target.value }))} placeholder="2" />
                      </div>
                    </div>

                    <div className="formRow">
                      <div className="field">
                        <div className="lab">Mikroçip No (ops.)</div>
                        <input className="input" value={petForm.microchip_no} onChange={(e) => setPetForm((p) => ({ ...p, microchip_no: e.target.value }))} placeholder="TR-..." />
                      </div>
                      <div className="field">
                        <div className="lab">Ayırt Edici Özellik (ops.)</div>
                        <input className="input" value={petForm.distinctive_marks} onChange={(e) => setPetForm((p) => ({ ...p, distinctive_marks: e.target.value }))} placeholder="Boynunda benek..." />
                      </div>
                    </div>

                    <div className="field">
                      <div className="lab">Renkler (ops.)</div>
                      <div className="toggleRow">
                        {(LOOKUP.colors || []).slice(0, 30).map((c) => {
                          const active = (petForm.color_ids || []).includes(c.color_id);
                          return (
                            <button
                              key={c.color_id}
                              className={`toggleBtn ${active ? "active" : ""}`}
                              onClick={() => togglePetColor(c.color_id)}
                              type="button"
                            >
                              {c.name}
                            </button>
                          );
                        })}
                      </div>
                      <div className="muted" style={{ marginTop: 8 }}>
                      </div>
                    </div>

                    <div className="heroRow" style={{ justifyContent: "flex-end" }}>
                      <button className="btn btnPrimary" disabled={busy} onClick={addPet} type="button">
                        {busy ? "Ekleniyor..." : "Evcil Hayvanı Kaydet"}
                      </button>
                    </div>
                  </div>

                  <div className="card section">
                    <h3 className="sectionTitle">Evcil Hayvanlarım</h3>
                    <div className="muted"></div>
                    <div className="splitLine" />

                    <div className="list">
                      {myPets.length === 0 && <div className="muted">Henüz evcil hayvan yok.</div>}
                      {myPets.map((p) => (
                        <div className="item" key={p.pet_id}>
                          <div className="itemTop">
                            <div>
                              <div className="itemTitle">
                                {findName(LOOKUP.species, "species_id", p.species_id)} {p.name ? `• ${p.name}` : ""}
                              </div>
                              <div className="itemMeta">
                                Cinsiyet: {p.sex || "—"} • Yaş: {p.age_years ?? "—"} • Renk: {petColorNames(p)}
                              </div>
                            </div>
                          </div>
                          <div className="itemBtns">
                            <button className="btn btnDanger" onClick={() => deletePet(p.pet_id)} disabled={busy} type="button">
                              Sil
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

{/* İLAN OLUŞTUR */}
{page === "ilan" && (
  <div className="card section">
    <h3 className="sectionTitle">İlan Oluştur</h3>
    <div className="muted">Kayıp/Bulundu ilanı oluştur. Fotoğraf ekleyebilirsin.</div>
    <div className="splitLine" />

    <div className="grid2">
      <div>
        <div className="formRow">
          <div className="field">
            <div className="lab">İlan Tipi</div>
            <select
              className="input"
              value={listingForm.listing_type}
              onChange={(e) => {
                const v = e.target.value;
                setListingForm((p) => ({
                  ...p,
                  listing_type: v,
                  species_id: v === "bulundu" ? p.species_id : "",
                }));
              }}
            >
              <option value="kayıp">Kayıp</option>
              <option value="bulundu">Bulundu</option>
            </select>
          </div>
          <div className="field">
            <div className="lab">Durum</div>
            <select className="input" value={listingForm.status} onChange={onListing("status")}>
              <option value="aktif">Aktif</option>
              <option value="çözüldü">Çözüldü</option>
            </select>
          </div>
        </div>

        <div className="field">
          <div className="lab">Başlık</div>
          <input
            className="input"
            value={listingForm.title}
            onChange={onListing("title")}
            placeholder="Örn: Beşiktaş’ta kayıp kedi"
          />
        </div>

        <div className="field">
          <div className="lab">Açıklama (ops.)</div>
          <textarea
            value={listingForm.description}
            onChange={onListing("description")}
            placeholder="En son nerede görüldü, ayırt edici özellik..."
          />
        </div>

        <div className="formRow">
          <div className="field">
            <div className="lab">Olay Zamanı (ops.)</div>
            <input
              className="input"
              value={listingForm.event_time}
              onChange={onListing("event_time")}
              placeholder="2025-12-17 12:30"
            />
          </div>
          <div className="field">
            <div className="lab">Evcil Seç (ops.)</div>
            <select className="input" value={listingForm.pet_id} onChange={onListing("pet_id")}>
              <option value="">Seçme</option>
              {myPets.map((p) => (
                <option key={p.pet_id} value={p.pet_id}>
                  {findName(LOOKUP.species, "species_id", p.species_id)} {p.name ? `• ${p.name}` : ""}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* ✅ Bulundu ilanı için tür seçimi */}
        {listingForm.listing_type === "bulundu" && (
          <div className="field">
            <div className="lab">Bulunan Hayvan Türü</div>
            <select className="input" value={listingForm.species_id} onChange={onListing("species_id")}>
              <option value="">Seç</option>
              {(LOOKUP.species || []).map((s) => (
                <option key={s.species_id} value={s.species_id}>
                  {s.name}
                </option>
              ))}
            </select>
            <div className="muted" style={{ marginTop: 6 }}>
              Bulundu ilanlarında pet kaydı olmayabilir. Bu yüzden tür seçimi gerekir.
            </div>
          </div>
        )}

        <div className="splitLine" />

        <div className="field">
          <div className="lab">Adres Seçimi</div>
          <div className="toggleRow">
            <button
              className={`toggleBtn ${addressMode === "kayitli" ? "active" : ""}`}
              onClick={() => setAddressMode("kayitli")}
              type="button"
            >
              Kayıtlı Adres
            </button>
            <button
              className={`toggleBtn ${addressMode === "yeni" ? "active" : ""}`}
              onClick={() => setAddressMode("yeni")}
              type="button"
            >
              Yeni Adres
            </button>
          </div>
        </div>

        {addressMode === "kayitli" ? (
          <div className="field">
            <div className="lab">Kayıtlı Adres</div>
            <select className="input" value={selectedAddressId} onChange={(e) => setSelectedAddressId(e.target.value)}>
              <option value="">Seç</option>
              {myAddresses.map((a) => (
                <option key={a.address_id} value={a.address_id}>
                  {addrLabelPretty(a)}
                </option>
              ))}
            </select>
            <div className="muted" style={{ marginTop: 6 }}>
              Kayıtlı adres yoksa önce “Adreslerim”den ekleyebilirsin.
            </div>
          </div>
        ) : (
          <>
            <div className="field">
              <div className="lab">Adres Etiketi</div>
              <input
                className="input"
                value={listingForm.address_label}
                onChange={onListing("address_label")}
                placeholder="Örn: Olay yeri"
              />
            </div>

            <div className="formRow">
              <div className="field">
                <div className="lab">Ülke</div>
                <select
                  className="input"
                  value={listingForm.country_id}
                  onChange={(e) =>
                    setListingForm((p) => ({
                      ...p,
                      country_id: e.target.value,
                      city_id: "",
                      district_id: "",
                      neighborhood_id: "",
                    }))
                  }
                >
                  <option value="">Seç</option>
                  {countries.map((c) => (
                    <option key={c.country_id} value={c.country_id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="field">
                <div className="lab">Şehir</div>
                <select
                  className="input"
                  value={listingForm.city_id}
                  onChange={(e) =>
                    setListingForm((p) => ({ ...p, city_id: e.target.value, district_id: "", neighborhood_id: "" }))
                  }
                >
                  <option value="">Seç</option>
                  {citiesForNewListing.map((c) => (
                    <option key={c.city_id} value={c.city_id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="formRow">
              <div className="field">
                <div className="lab">İlçe</div>
                <select
                  className="input"
                  value={listingForm.district_id}
                  onChange={(e) =>
                    setListingForm((p) => ({ ...p, district_id: e.target.value, neighborhood_id: "" }))
                  }
                >
                  <option value="">Seç</option>
                  {districtsForNewListing.map((d) => (
                    <option key={d.district_id} value={d.district_id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="field">
                <div className="lab">Mahalle</div>
                <select className="input" value={listingForm.neighborhood_id} onChange={onListing("neighborhood_id")}>
                  <option value="">Seç</option>
                  {neighborhoodsForNewListing.map((n) => (
                    <option key={n.neighborhood_id} value={n.neighborhood_id}>
                      {n.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="formRow">
              <div className="field">
                <div className="lab">Sokak (ops.)</div>
                <input className="input" value={listingForm.street} onChange={onListing("street")} placeholder="Sokak" />
              </div>
              <div className="field">
                <div className="lab">Bina No (ops.)</div>
                <input
                  className="input"
                  value={listingForm.building_no}
                  onChange={onListing("building_no")}
                  placeholder="12"
                />
              </div>
            </div>

            <div className="formRow">
              <div className="field">
                <div className="lab">Daire No (ops.)</div>
                <input
                  className="input"
                  value={listingForm.apartment_no}
                  onChange={onListing("apartment_no")}
                  placeholder="5"
                />
              </div>
              <div className="field">
                <div className="lab">Posta Kodu (ops.)</div>
                <input
                  className="input"
                  value={listingForm.postal_code}
                  onChange={onListing("postal_code")}
                  placeholder="34xxx"
                />
              </div>
            </div>
          </>
        )}
      </div>

      <div>
        <div className="card section" style={{ boxShadow: "none", border: "1px solid rgba(15,23,42,.08)" }}>
          <h3 className="sectionTitle" style={{ marginBottom: 6 }}>
            Fotoğraflar
          </h3>
          <div className="muted">En fazla 6 fotoğraf • 2.5MB sınırı</div>
          <div className="splitLine" />

          <input ref={fileInputRef} type="file" accept="image/*" multiple style={{ display: "none" }} onChange={onPickFiles} />
          <button className="btn btnPrimary" onClick={openFilePicker} type="button">
            Fotoğraf Ekle
          </button>

          {(listingForm.photo_items || []).length > 0 && (
            <>
              <div className="thumbRow">
                {listingForm.photo_items.map((it) => (
                  <div className="thumb" key={it.temp_id} title={it.file_name}>
                    <img src={it.data_url} alt={it.file_name || "foto"} />
                  </div>
                ))}
              </div>
              <div className="itemBtns">
                {(listingForm.photo_items || []).map((it) => (
                  <button className="btn btnDanger" key={it.temp_id} onClick={() => removePhotoItem(it.temp_id)} type="button">
                    {it.file_name ? `"${it.file_name}" Sil` : "Foto Sil"}
                  </button>
                ))}
              </div>
            </>
          )}

          <div className="splitLine" />

          <div className="muted">
            Seçili evcil: <b>{listingPetTitle(listingForm.pet_id)}</b>
          </div>

          <div className="heroRow" style={{ justifyContent: "flex-end" }}>
            <button className="btn btnPrimary" disabled={busy} onClick={submitListing} type="button">
              {busy ? "Gönderiliyor..." : "İlanı Yayınla"}
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
)}
              {/* KEŞFET */}
              {page === "kesfet" && (
                <div className="card section">
                  <h3 className="sectionTitle">Keşfet</h3>
                  <div className="muted">Tüm ilanlar listelenir. Arama + filtre.</div>
                  <div className="splitLine" />

                  <div className="formRow">
                    <div className="field">
                      <div className="lab">Arama</div>
                      <input className="input" value={exploreSearch} onChange={(e) => setExploreSearch(e.target.value)} placeholder="Başlık / açıklama içinde ara..." />
                    </div>
                    <div className="field">
                      <div className="lab">Filtre</div>
                      <select className="input" value={exploreType} onChange={(e) => setExploreType(e.target.value)}>
                        <option value="hepsi">Hepsi</option>
                        <option value="kayıp">Kayıp</option>
                        <option value="bulundu">Bulundu</option>
                      </select>
                    </div>
                  </div>

                  <div className="list">
                    {filteredListings.length === 0 && <div className="muted">İlan bulunamadı.</div>}
                    {filteredListings.map((l) => {
                      const isMine = String(l.created_by) === String(authedUser?.user_id);
                      const badgeCls = l.listing_type === "kayıp" ? "badgeKayıp" : "badgeBulundu";
                      return (
                        <div className="item" key={l.listing_id}>
                          <div className="itemTop">
                            <div>
                                <div className="itemTitle">
                                <span className={`badge ${badgeCls}`}>{l.listing_type.toUpperCase()}</span>{" "}
                                <span style={{ marginLeft: 8 }}>{l.title}</span>
                              </div>
<div className="itemMeta">
  Konum:{" "}
  <b>
    {l.address_id
      ? (addressTextCache[l.address_id] || "Yükleniyor...")
      : "—"}
  </b>
</div>

                              {l.description && <div className="itemMeta">Açıklama: {l.description}</div>}
                            </div>
                            <div style={{ textAlign: "right" }}>
                              {isMine && <span className="badge">Benim ilanım</span>}
                            </div>
                          </div>

                          <div className="itemBtns">
                            <button
                              className="btn btnGhost"
                              onClick={async () => {
                                const photos = await ensureListingPhotos(l.listing_id);
                                if (!photos.length) return alert("Bu ilanda fotoğraf yok.");
                                // basit: ilk fotoğrafı göster
                                alert(`Fotoğraf sayısı: ${photos.length}\nİlk dosya: ${photos[0]?.file_name || "—"}`);
                              }}
                              disabled={busy}
                              type="button"
                            >
                              Fotoğraflar
                            </button>

                            {!isMine && (
                              <button className="btn btnPrimary" onClick={() => openOrCreateConversationForListing(l)} disabled={busy} type="button">
                                Mesaj Gönder
                              </button>
                            )}

                            {isMine && l.status !== "çözüldü" && (
                              <button className="btn btnGhost" onClick={() => markSolved(l.listing_id)} disabled={busy} type="button">
                                Çözüldü İşaretle
                              </button>
                            )}

                            {isMine && (
                              <button className="btn btnDanger" onClick={() => deleteListing(l.listing_id)} disabled={busy} type="button">
                                Sil
                              </button>
                            )}
                          </div>

                          {/* inline foto thumb (cache varsa) */}
                          {Array.isArray(listingPhotosCache[l.listing_id]) && listingPhotosCache[l.listing_id].length > 0 && (
                            <div className="thumbRow">
                              {listingPhotosCache[l.listing_id].slice(0, 6).map((ph) => (
                                <div className="thumb" key={ph.photo_id || ph.listing_photo_id || ph.file_name}>
                                  {ph.data_url ? <img src={ph.data_url} alt={ph.file_name || "foto"} /> : <span className="muted">img</span>}
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* MESAJLAR */}
              {page === "mesajlar" && (
                <div className="gridChat">
                  {/* sol: conversations */}
                  <div className="card section chatList">
                    <h3 className="sectionTitle">Konuşmalar</h3>
                    <div className="muted">İlan üzerinden konuşma açılır.</div>
                    <div className="splitLine" />

                    <div className="list">
                      {conversations.length === 0 && <div className="muted">Henüz konuşma yok.</div>}
                      {conversations.map((c) => {
                        const isActive = String(c.conversation_id) === String(activeConversationId || "");
                        const otherId = getOtherParticipantId(c.conversation_id);
                        const last = convLastMessage(c.conversation_id);
                        return (
                          <div
                            className="item"
                            key={c.conversation_id}
                            style={{ cursor: "pointer", borderColor: isActive ? "rgba(24,75,151,.45)" : "rgba(15,23,42,.08)" }}
                            onClick={() => setActiveConversationId(c.conversation_id)}
                          >
                            <div className="itemTitle">{getConversationTitle(c)}</div>
                            <div className="itemMeta">
                              Karşı: <b>{otherId ? `Kullanıcı: ${otherId}` : "—"}</b>
                            </div>
                            {last && <div className="itemMeta">Son: “{String(last.body || "").slice(0, 70)}”</div>}
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* sağ: chat */}
                  <div className="card section chatWrap">
                    <h3 className="sectionTitle">Mesajlar</h3>
                    {!activeConversationId && <div className="muted">Soldan bir konuşma seç.</div>}

                    {activeConversationId && (
                      <>
                        <div className="muted" style={{ marginTop: -6 }}>
                          Konuşma ID: <b>{activeConversationId}</b>
                        </div>

                        <div className="splitLine" />

                        <div className="chatMessages">
                          {activeMessages.length === 0 && <div className="muted">Henüz mesaj yok.</div>}
                          {activeMessages.map((m) => {
                            const isMe = String(m.sender_user_id) === String(authedUser?.user_id);
                            return (
                              <div className={`msgRow ${isMe ? "msgMe" : ""}`} key={m.message_id || `${m.created_at}_${m.sender_user_id}`}>
                                <div className="msgBubble">
                                  <div style={{ whiteSpace: "pre-wrap" }}>{m.body}</div>
                                  <div className="msgMeta">
                                    <span>{isMe ? "Sen" : `Kullanıcı: ${m.sender_user_id}`}</span>
                                    <span>•</span>
                                    <span>{m.created_at ? new Date(m.created_at).toLocaleString("tr-TR") : "—"}</span>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        <div className="chatComposer">
                          <textarea value={chatDraft} onChange={(e) => setChatDraft(e.target.value)} placeholder="Mesaj yaz..." />
                          <button className="btn btnPrimary" onClick={sendMessage} disabled={busy} type="button">
                            Gönder
                          </button>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* EŞLEŞMELER */}
              {page === "eslesmeler" && (
                <div className="card section">
                  <h3 className="sectionTitle">Eşleşmeler</h3>
                  <div className="muted">
                    Aktif “kayıp” ilanını seç — sistem aynı şehirdeki “bulundu” ilanlarını uygunluk skoruna göre sıralar.
                  </div>
                  <div className="splitLine" />

                  {myActiveLostListings.length === 0 ? (
                    <div className="muted">Aktif kayıp ilanın yok. Önce “İlan Oluştur”dan kayıp ilanı aç.</div>
                  ) : (
                    <>
                      <div className="formRow">
                        <div className="field">
                          <div className="lab">Kayıp İlanın</div>
                          <select
                            className="input"
                            value={matchesLostId}
                            onChange={(e) => setMatchesLostId(e.target.value)}
                          >
                            {myActiveLostListings.map((l) => (
                              <option key={l.listing_id} value={l.listing_id}>
                                {l.title} • {l.created_at ? new Date(l.created_at).toLocaleDateString("tr-TR") : ""}
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="field" style={{ display: "flex", justifyContent: "flex-end" }}>
                          <div style={{ alignSelf: "flex-end" }}>
                            <button
                              className="btn btnGhost"
                              onClick={() => fetchMatches(matchesLostId)}
                              disabled={busy || matchesLoading || !matchesLostId}
                              type="button"
                            >
                              {matchesLoading ? "Eşleşmeler aranıyor..." : "Tekrar Hesapla"}
                            </button>
                          </div>
                        </div>
                      </div>

                      {matchesErr && (
                        <div style={{ padding: 10, borderRadius: 12, background: "rgba(239,68,68,.10)", border: "1px solid rgba(239,68,68,.18)" }}>
                          <b>Hata:</b> {matchesErr}
                          <div className="muted" style={{ marginTop: 6 }}>
                            Not: Backend’de <code>/matches/&lt;lost_listing_id&gt;</code> endpoint’i tanımlı olmalı.
                          </div>
                        </div>
                      )}

                      <div className="list">
                        {matchesLoading && <div className="muted">Yükleniyor...</div>}
                        {!matchesLoading && matchesRows.length === 0 && !matchesErr && (
                          <div className="muted">Bu kayıp ilanı için uygun “bulundu” ilanı bulunamadı.</div>
                        )}

                        {matchesRows.map((m) => {
                          const foundListing = (listings || []).find((x) => String(x.listing_id) === String(m.found_listing_id));
                          const title = foundListing?.title || "Bulundu ilanı";
                          const who = m.created_by ? `Kullanıcı: ${m.created_by}` : (foundListing?.created_by ? `Kullanıcı: ${foundListing.created_by}` : "—");

                          return (
                            <div className="item" key={`${matchesLostId}_${m.found_listing_id}`}>
                              <div className="itemTop">
                                <div>
                                  <div className="itemTitle">
                                    <span className="badge badgeBulundu">BULUNDU</span>
                                    <span style={{ marginLeft: 8 }}>{title}</span>
                                  </div>

                                  <div className="itemMeta">
                                  Sahip: <b>{who}</b>
                                  </div>


<div className="itemMeta">
  Konum:{" "}
  <b>
    {(m.found_neighborhood_name || "—") + ", " +
     (m.found_district_name || "—") + " / " +
     (m.found_city_name || "—")}
  </b>
</div>

<div className="itemMeta">
  Tür uyumu: <b>{m.species_match ? "Evet" : "Hayır"}</b>{" "}
  • Mahalle uyumu: <b>{m.neighborhood_match ? "Evet" : "Hayır"}</b>{" "}
  • İlçe uyumu: <b>{m.district_match ? "Evet" : "Hayır"}</b>{" "}
  • Ortak renk: <b>{m.shared_color_count ?? 0}</b>{" "}
  • Cinsiyet uyumu: <b>{m.sex_match ? "Evet" : "Hayır"}</b>
</div>
                                </div>

                                <div style={{ textAlign: "right" }}>
                                  <span className="badge">#{String(m.found_listing_id).slice(0, 6)}</span>
                                </div>
                              </div>

                              <div className="itemBtns">
                                <button
                                  className="btn btnGhost"
                                  onClick={async () => {
                                    const photos = await ensureListingPhotos(m.found_listing_id);
                                    if (!photos.length) return alert("Bu ilanda fotoğraf yok.");
                                    alert(`Fotoğraf sayısı: ${photos.length}\nİlk dosya: ${photos[0]?.file_name || "—"}`);
                                  }}
                                  disabled={busy}
                                  type="button"
                                >
                                  Fotoğraflar
                                </button>

                                {m.created_by && String(m.created_by) !== String(authedUser?.user_id) && (
                                  <button
                                    className="btn btnPrimary"
                                    onClick={async () => {
                                      // found listing obj yoksa da açabiliriz: listing_id + user_b lazım
                                      const createdBy = m.created_by;
                                      await apiSend("/conversations/open", "POST", {
                                        listing_id: m.found_listing_id,
                                        user_a: authedUser.user_id,
                                        user_b: createdBy,
                                      });
                                      await refreshAll();
                                      setNav("mesajlar");
                                    }}
                                    disabled={busy}
                                    type="button"
                                  >
                                    Mesaj Gönder
                                  </button>
                                )}
                              </div>

                              {/* foto thumb */}
                              {Array.isArray(listingPhotosCache[m.found_listing_id]) && listingPhotosCache[m.found_listing_id].length > 0 && (
                                <div className="thumbRow">
                                  {listingPhotosCache[m.found_listing_id].slice(0, 6).map((ph) => (
                                    <div className="thumb" key={ph.photo_id || ph.file_name}>
                                      {ph.data_url ? <img src={ph.data_url} alt={ph.file_name || "foto"} /> : <span className="muted">img</span>}
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </>
                  )}
                </div>
              )}

              {/* PROFİL */}
              {page === "profil" && (
                <div className="card section">
                  <h3 className="sectionTitle">Profil</h3>
                  <div className="muted">Backend’de kullanıcı güncelleme endpoint’i yoksa burada sadece görüntüleriz.</div>
                  <div className="splitLine" />

                  <div className="item">
                    <div className="itemTitle">{authedUser?.full_name || `Kullanıcı: ${authedUser?.user_id}`}</div>
                    <div className="itemMeta">E-posta: {authedUser?.email || "—"}</div>
                    <div className="itemMeta">Telefon: {authedUser?.phone || "—"}</div>
                    <div className="itemMeta">Birincil Adres ID: {authedUser?.primary_address_id ?? "—"}</div>
                  </div>

                  <div className="heroRow" style={{ justifyContent: "flex-end" }}>
                    <button className="btn btnGhost" onClick={() => setNav("adresler")} type="button">
                      Adreslerime Git
                    </button>
                    <button className="btn btnGhost" onClick={() => setNav("evcil")} type="button">
                      Evcil Hayvanlarıma Git
                    </button>
                  </div>
                </div>
              )}
            </div>
          </main>
        </div>
      )}
    </div>
  );
}
