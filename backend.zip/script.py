import os
import re
import base64
import random
import mimetypes
from pathlib import Path
from datetime import datetime, timedelta

import psycopg2
from psycopg2.extras import execute_values

# ======================================================
# CONFIG
# ======================================================
DB_DSN = os.getenv(
    "DB_DSN",
    "postgresql://postgres:password@localhost:5432/vtys_proje"
)
IMAGE_ROOT = Path("veritabani_veri")

CAT_DIR = IMAGE_ROOT / "kedi"
DOG_DIR = IMAGE_ROOT / "kopek"

N_USERS = int(os.getenv("N_USERS", "500"))
N_LISTINGS = int(os.getenv("N_LISTINGS", "1000"))
MAX_PHOTOS_PER_LISTING = int(os.getenv("MAX_PHOTOS_PER_LISTING", "1"))

# sohbet üretimi (istersen 0 yap)
ENABLE_CONVERSATIONS = os.getenv("ENABLE_CONVERSATIONS", "1") == "1"

random.seed(39)

FIRST_NAMES = [
    "Ahmet","Mehmet","Ayşe","Fatma","Elif","Zeynep","Can","Ece","Mert","Deniz",
    "Yusuf","Emir","Aslı","Seda","Kaan","Selin","Berk","İrem","Onur","Ceren"
]
LAST_NAMES = [
    "Yılmaz","Kaya","Demir","Şahin","Çelik","Aydın","Arslan","Doğan","Kılıç","Koç",
    "Öztürk","Yıldız","Aksoy","Erdem","Polat","Güneş","Taş","Kurt","Sezer","Bulut"
]
STREETS = ["Atatürk Cd.","İnönü Sk.","Bağdat Cd.","Cumhuriyet Cd.","Gül Sk.","Çınar Sk.","Sahil Yolu","Park Sk."]

PET_NAMES = ["Mia","Pamuk","Leo","Zeytin","Tekir","Boncuk","Karamel","Loki","Pati","Max","Charlie","Duman","Bulut","Şanslı"]

LISTING_TITLES_LOST = [
    "Kayıp kedim aranıyor", "Kayıp köpeğim kayboldu", "Evcil hayvanım kayıp", "Gören olursa lütfen iletişime geçin",
    "Acil! Kayıp ilanı", "Kayıp evcil hayvan - yardım"
]
LISTING_TITLES_FOUND = [
    "Bulundu: Sahipsiz kedi", "Bulundu: Sahipsiz köpek", "Mahallede bulunan hayvan", "Sahibini arıyoruz",
    "Bulundu - iletişime geçin", "Sahibini arıyoruz (bulundu)"
]

STATUS_CHOICES = ["aktif", "çözüldü", "iptal"]
STATUS_WEIGHTS = [0.78, 0.18, 0.00]  

SEX_CHOICES = ["erkek", "dişi", "bilinmiyor"]
SEX_WEIGHTS = [0.45, 0.45, 0.10]

DESCRIPTION_TEMPLATES = [
    "En son {neighborhood} civarında görüldü. Gören olursa lütfen haber versin.",
    "{date} tarihinde kayboldu. Oldukça {temper} bir hayvandır.",
    "Mahallede {time} saatlerinde görüldüğü söylendi.",
    "Üzerinde {accessory} vardı. Dikkat çekici bir {feature} bulunuyor.",
    "İnsanlara karşı {temper}, korkabilir. Yaklaşırken dikkatli olun.",
    "Etrafta dolaşmayı seviyor ama eve geri dönmedi.",
    "Gören ya da bulan olursa lütfen mesaj atsın.",
    "Çok uysal, yabancılara yaklaşabilir.",
    "Seslenince tepki veriyor olabilir. İsmi: {pet_name}.",
    "Fotoğraflardaki hayvana benziyorsa iletişime geçin."
]
TEMPER_WORDS = ["ürkek", "uysal", "hareketli", "sakin", "oyuncu", "çekingen"]
ACCESSORIES = ["kırmızı tasma", "mavi tasma", "tasması yoktu", "zil bulunan tasma", "yelek/tasma", "mor tasma"]
FEATURES = ["beyaz pati", "yeşil göz", "siyah burun", "tekir desen", "kısa kuyruk", "benekli tüy"]


# ======================================================
# HELPERS
# ======================================================
def slugify(s: str) -> str:
    s = s.lower()
    s = s.replace("ı", "i").replace("ğ", "g").replace("ü", "u").replace("ş", "s").replace("ö", "o").replace("ç", "c")
    s = re.sub(r"[^a-z0-9]+", ".", s).strip(".")
    return s

def pick_random_file(folder: Path) -> Path | None:
    if not folder.exists():
        return None
    files = []
    for ext in (".jpg", ".jpeg", ".png", ".webp"):
        files.extend(folder.glob(f"*{ext}"))
    return random.choice(files) if files else None

def file_to_data_url(p: Path) -> str:
    mime, _ = mimetypes.guess_type(str(p))
    if not mime:
        mime = "image/jpeg"
    b64 = base64.b64encode(p.read_bytes()).decode("utf-8")
    return f"data:{mime};base64,{b64}"

def rand_event_time_str() -> str:
    dt = datetime.now() - timedelta(
        days=random.randint(0, 30),
        hours=random.randint(0, 23),
        minutes=random.choice([0, 10, 15, 20, 30, 45]),
    )
    return dt.strftime("%Y-%m-%d %H:%M")

def rand_phone() -> str:
    return f"05{random.randint(0,9)}{random.randint(10000000,99999999)}"

def fake_hash() -> str:
    return "demo_hash_" + "".join(random.choice("abcdef0123456789") for _ in range(24))

def random_description(neighborhood: str | None = None, pet_name: str | None = None) -> str:
    tpl = random.choice(DESCRIPTION_TEMPLATES)
    text = tpl.format(
        neighborhood=neighborhood or "bulunduğu bölge",
        date=(datetime.now() - timedelta(days=random.randint(0, 15))).strftime("%d.%m.%Y"),
        time=f"{random.randint(8,22)}:{random.choice(['00','15','30','45'])}",
        temper=random.choice(TEMPER_WORDS),
        accessory=random.choice(ACCESSORIES),
        feature=random.choice(FEATURES),
        pet_name=pet_name or random.choice(PET_NAMES),
    )

    if random.random() < 0.60:
        text += " " + random.choice([
            "Ödül verilecektir.",
            "Acil geri dönüş bekleniyor.",
            "Çocuklar çok üzgün.",
            "Sahibi tarafından çok sevilen bir hayvan.",
            "Lütfen yanlış ihbar yapmayın.",
        ])
    if random.random() < 0.25:
        text += " " + random.choice([
            "Gece saatlerinde daha aktif olabilir.",
            "Kapalı alanlara girmiş olabilir.",
            "Su ve mama ile yaklaşmak işe yarayabilir.",
        ])
    return text


# ======================================================
# SQL
# ======================================================
Q = {
    "countries": "SELECT country_id FROM countries",
    "cities": "SELECT city_id FROM cities",
    "districts_by_city": "SELECT district_id FROM districts WHERE city_id=%s",
    "neigh_by_dist": "SELECT neighborhood_id FROM neighborhoods WHERE district_id=%s",
    "species": "SELECT species_id, name FROM species",
    "colors": "SELECT color_id FROM colors",
    "insert_users": """
        INSERT INTO users (full_name, email, phone, password_hash)
        VALUES %s
        RETURNING user_id, email
    """,
    "set_primary_address": "UPDATE users SET primary_address_id=%s, updated_at=now() WHERE user_id=%s",
    "insert_user_addresses": """
        INSERT INTO user_addresses (user_id, address_id, is_default)
        VALUES %s
        ON CONFLICT DO NOTHING
    """,
    "insert_pets": """
        INSERT INTO pets (owner_user_id, species_id, name, sex, age_years, microchip_no, distinctive_marks)
        VALUES %s
        RETURNING pet_id, owner_user_id, species_id, name
    """,
    "insert_pet_colors": """
        INSERT INTO pet_colors (pet_id, color_id)
        VALUES %s
        ON CONFLICT DO NOTHING
    """,
    "insert_listings": """
        INSERT INTO listings (created_by, pet_id, address_id, listing_type, status, title, description, event_time, species_id)
        VALUES %s
        RETURNING listing_id
    """,
    "insert_listing_photos": """
        INSERT INTO listing_photos (listing_id, file_name, data_url, sort_order)
        VALUES %s
    """,
    "insert_conversations": """
        INSERT INTO conversations (listing_id)
        VALUES %s
        RETURNING conversation_id
    """,
    "insert_participants": """
        INSERT INTO conversation_participants (conversation_id, user_id, role)
        VALUES %s
        ON CONFLICT DO NOTHING
    """,
    "insert_messages": """
        INSERT INTO messages (conversation_id, sender_user_id, body)
        VALUES %s
    """,
}


def main():
    print("[INFO] Connecting:", DB_DSN)
    conn = psycopg2.connect(DB_DSN)
    conn.autocommit = False

    try:
        with conn.cursor() as cur:
            # ---------- lookup checks ----------
            cur.execute(Q["countries"])
            countries = [r[0] for r in cur.fetchall()]
            if not countries:
                raise RuntimeError("countries boş. Önce lookup seed çalıştır.")

            cur.execute(Q["cities"])
            cities = [r[0] for r in cur.fetchall()]
            if not cities:
                raise RuntimeError("cities boş. Önce lookup seed çalıştır.")

            cur.execute(Q["species"])
            species_rows = cur.fetchall()
            if not species_rows:
                raise RuntimeError("species boş. Önce lookup seed çalıştır.")

            species_map = {name.lower(): sid for sid, name in species_rows}
            cat_species_id = species_map.get("kedi")
            dog_species_id = species_map.get("köpek") or species_map.get("kopek")
            if not cat_species_id or not dog_species_id:
                raise RuntimeError("species içinde 'Kedi' ve 'Köpek' yok gibi görünüyor.")

            cur.execute(Q["colors"])
            colors = [r[0] for r in cur.fetchall()]
            if not colors:
                raise RuntimeError("colors boş. Önce lookup seed çalıştır.")

            # ---------- 1) users ----------
            users_payload = []
            used_emails = set()
            for _ in range(N_USERS):
                fn = random.choice(FIRST_NAMES)
                ln = random.choice(LAST_NAMES)
                full = f"{fn} {ln}"
                base = slugify(full)
                email = f"{base}{random.randint(1,9999)}@gmail.com"
                while email in used_emails:
                    email = f"{base}{random.randint(1,9999)}@gmail.com"
                used_emails.add(email)
                users_payload.append((full, email, rand_phone(), fake_hash()))

            execute_values(cur, Q["insert_users"], users_payload)
            users = cur.fetchall()  # (user_id, email)
            user_ids = [u[0] for u in users]
            print(f"[OK] users: {len(user_ids)}")

            # ---------- 2) addresses + user_addresses + primary_address_id ----------
            user_address_rows = []
            default_addr_for_user = {}

            for uid in user_ids:
                n_addr = 1 if random.random() < 0.7 else 2
                created_addr_ids = []

                for j in range(n_addr):
                    city_id = random.choice(cities)
                    cur.execute(Q["districts_by_city"], (city_id,))
                    dists = [r[0] for r in cur.fetchall()]
                    if not dists:
                        continue
                    district_id = random.choice(dists)

                    cur.execute(Q["neigh_by_dist"], (district_id,))
                    neighs = [r[0] for r in cur.fetchall()]
                    if not neighs:
                        continue
                    neighborhood_id = random.choice(neighs)

                    country_id = countries[0]  # genelde TR = '1'
                    address_label = random.choice(["Ev", "İş", "Ailem", "Yazlık", "Ofis"])
                    street = random.choice(STREETS)
                    building_no = str(random.randint(1, 200))
                    apartment_no = str(random.randint(1, 50))
                    postal_code = str(random.randint(10000, 99999))

                    cur.execute(
                        """
                        INSERT INTO addresses (country_id, city_id, district_id, neighborhood_id, address_label, street, building_no, apartment_no, postal_code)
                        VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)
                        RETURNING address_id
                        """,
                        (country_id, city_id, district_id, neighborhood_id, address_label, street, building_no, apartment_no, postal_code),
                    )
                    aid = cur.fetchone()[0]
                    created_addr_ids.append(aid)

                    is_default = (j == 0)
                    user_address_rows.append((uid, aid, is_default))
                    if is_default:
                        default_addr_for_user[uid] = aid

            execute_values(cur, Q["insert_user_addresses"], user_address_rows)

            for uid, aid in default_addr_for_user.items():
                cur.execute(Q["set_primary_address"], (aid, uid))

            print(f"[OK] addresses: {len(user_address_rows)} links")

            # ---------- 3) pets + pet_colors ----------
            pets_payload = []
            for uid in user_ids:
                r = random.random()
                n_pets = 0 if r < 0.15 else (1 if r < 0.75 else 2)

                for _ in range(n_pets):
                    sp = cat_species_id if random.random() < 0.6 else dog_species_id
                    pet_name = random.choice(PET_NAMES)
                    sex = random.choices(SEX_CHOICES, weights=SEX_WEIGHTS, k=1)[0]
                    age_years = random.choice([None, 0, 1, 2, 3, 4, 5, 6, 7, 8, 10])
                    microchip = None if random.random() < 0.7 else f"TR{random.randint(100000000,999999999)}"
                    marks = random.choice([
                        None,
                        "Boynunda tasma vardı.",
                        "Kulağında küçük kesik var.",
                        "Beyaz patili, gözleri yeşil.",
                        "Çok uysal, insanlara yaklaşır."
                    ])
                    pets_payload.append((uid, sp, pet_name, sex, age_years, microchip, marks))

            pets_inserted = []
            if pets_payload:
                execute_values(cur, Q["insert_pets"], pets_payload)
                pets_inserted = cur.fetchall()  

            print(f"[OK] pets: {len(pets_inserted)}")

            owner_pets = {}
            for pid, ouid, spid, pname in pets_inserted:
                owner_pets.setdefault(ouid, []).append((pid, spid, pname))

            pet_color_rows = []
            for pid, _, _, _ in pets_inserted:
                n = 1 if random.random() < 0.7 else 2
                for cid in random.sample(colors, k=min(n, len(colors))):
                    pet_color_rows.append((pid, cid))
            if pet_color_rows:
                execute_values(cur, Q["insert_pet_colors"], pet_color_rows)

            # ---------- 4) listings + photos ----------
            cur.execute("SELECT user_id, address_id FROM user_addresses")
            ua = cur.fetchall()
            if not ua:
                raise RuntimeError("user_addresses boş kaldı, address üretilememiş.")
            user_to_addresses = {}
            for uid, aid in ua:
                user_to_addresses.setdefault(uid, []).append(aid)

            listing_rows = []
            listing_context = [] 
            for _ in range(N_LISTINGS):
                created_by = random.choice(user_ids)
                addr_list = user_to_addresses.get(created_by)
                if not addr_list:
                    continue
                address_id = random.choice(addr_list)

                listing_type = "kayıp" if random.random() < 0.55 else "bulundu"
                status = random.choices(STATUS_CHOICES, weights=STATUS_WEIGHTS, k=1)[0]

                pet_id = None
                species_id = None
                pet_name_for_desc = None

                if listing_type == "kayıp":
                    pets_of_user = owner_pets.get(created_by, [])
                    if pets_of_user and random.random() < 0.85:
                        pet_id, species_id, pet_name_for_desc = random.choice(pets_of_user)

                if not species_id:
                    species_id = cat_species_id if random.random() < 0.6 else dog_species_id

                cur.execute("""
                    SELECT n.name
                    FROM addresses a
                    JOIN neighborhoods n ON n.neighborhood_id = a.neighborhood_id
                    WHERE a.address_id = %s
                """, (address_id,))
                row = cur.fetchone()
                neigh_name = row[0] if row else None

                title = random.choice(LISTING_TITLES_LOST if listing_type == "kayıp" else LISTING_TITLES_FOUND)
                description = random_description(neigh_name, pet_name_for_desc)
                event_time = rand_event_time_str()

                listing_rows.append((
                    created_by, pet_id, address_id,
                    listing_type, status,
                    title, description, event_time,
                    species_id
                ))
                listing_context.append((address_id, species_id))

            execute_values(cur, Q["insert_listings"], listing_rows)
            listing_ids = [r[0] for r in cur.fetchall()]
            print(f"[OK] listings: {len(listing_ids)}")

            # photos
            photo_rows = []
            for lid in listing_ids:
                cur.execute("SELECT species_id FROM listings WHERE listing_id=%s", (lid,))
                spid = cur.fetchone()[0]

                folder = CAT_DIR if spid == cat_species_id else DOG_DIR
                n_ph = random.randint(1, MAX_PHOTOS_PER_LISTING)

                for i in range(n_ph):
                    fp = pick_random_file(folder)
                    if not fp:
                        continue
                    data_url = file_to_data_url(fp)
                    photo_rows.append((lid, fp.name, data_url, i))

            if photo_rows:
                execute_values(cur, Q["insert_listing_photos"], photo_rows)
            print(f"[OK] listing_photos: {len(photo_rows)}")

            # ---------- 5) optional conversations/messages ----------
            if ENABLE_CONVERSATIONS:
                cur.execute("SELECT listing_id, created_by FROM listings WHERE status='aktif' ORDER BY created_at DESC")
                active_listings = cur.fetchall()

                conv_rows = []
                for listing_id, _owner_id in active_listings:
                    if random.random() < 0.35:
                        conv_rows.append((listing_id,))

                if conv_rows:
                    execute_values(cur, Q["insert_conversations"], conv_rows)
                    _conv_ids = [r[0] for r in cur.fetchall()]

                    cur.execute("""
                        SELECT c.conversation_id, c.listing_id, l.created_by
                        FROM conversations c
                        JOIN listings l ON l.listing_id = c.listing_id
                        WHERE c.created_at > now() - interval '10 minutes'
                    """)
                    conv_listing_map = cur.fetchall()

                    part_rows = []
                    msg_rows = []
                    msgs = [
                        "Merhaba, ilanı gördüm. Nerede kayboldu/bulundu?",
                        "Selam! Yakın zamanda burada gördüm olabilir.",
                        "Fotoğraftaki hayvana benziyor, detay alabilir miyim?",
                        "İletişim numarası bırakabilir misiniz?",
                        "Benzerini gördüm, konum atabilir misiniz?",
                    ]

                    for cid, _lid, owner_id in conv_listing_map:
                        other = random.choice([u for u in user_ids if u != owner_id])
                        part_rows.append((cid, owner_id, "owner"))
                        part_rows.append((cid, other, "participant"))

                        k = random.randint(2, 4)
                        for mi in range(k):
                            sender = owner_id if mi % 2 == 0 else other
                            body = random.choice(msgs)
                            msg_rows.append((cid, sender, body))

                    if part_rows:
                        execute_values(cur, Q["insert_participants"], part_rows)
                    if msg_rows:
                        execute_values(cur, Q["insert_messages"], msg_rows)

                    print(f"[OK] conversations: {len(conv_listing_map)} / messages: {len(msg_rows)}")

            conn.commit()
            print("\n[DONE] Seed completed successfully.")

    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


if __name__ == "__main__":
    if not CAT_DIR.exists():
        print(f"[WARN] Kedi klasörü yok: {CAT_DIR}")
    if not DOG_DIR.exists():
        print(f"[WARN] Köpek klasörü yok: {DOG_DIR}")
    main()
