import os
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import ORJSONResponse
from pydantic import BaseModel, EmailStr, Field
from sqlalchemy import create_engine, text
from starlette.middleware.base import BaseHTTPMiddleware


# =========================
# UTF-8 JSON Middleware
# =========================
class Utf8JSONMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        ct = response.headers.get("content-type", "")
        if "application/json" in ct and "charset" not in ct:
            response.headers["content-type"] = "application/json; charset=utf-8"
        return response


# =========================
# APP
# =========================
app = FastAPI(
    title="LostPet API",
    default_response_class=ORJSONResponse,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # offline demo için serbest
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(Utf8JSONMiddleware)


@app.get("/health")
def health():
    return {"status": "ok"}


# =========================
# DB CONFIG
# =========================
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")

DATABASE_URL = f"postgresql+psycopg://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
engine = create_engine(DATABASE_URL, pool_pre_ping=True)


# =========================
# HELPERS
# =========================
def one_or_404(row, msg="Kayıt bulunamadı"):
    if not row:
        raise HTTPException(status_code=404, detail=msg)
    return row


def as_uuid_str(v):
    return str(v) if v is not None else None


# =========================
# HEALTH / DB
# =========================
@app.get("/db/ping")
def db_ping():
    with engine.connect() as conn:
        v = conn.execute(text("SELECT 1")).scalar_one()
    return {"status": "ok", "db": v}


# =========================
# AUTH MODELS
# =========================
class RegisterIn(BaseModel):
    full_name: str
    email: EmailStr
    phone: Optional[str] = None
    password: str


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    user_id: str
    full_name: str
    email: str
    phone: Optional[str] = None
    primary_address_id: Optional[str] = None


# =========================
# AUTH ROUTES
# =========================
@app.post("/auth/register", response_model=UserOut)
def register(data: RegisterIn):
    with engine.begin() as conn:
        exists = conn.execute(
            text("SELECT 1 FROM users WHERE email=:email"),
            {"email": str(data.email)},
        ).first()
        if exists:
            raise HTTPException(status_code=409, detail="E-posta kayıtlı")

        row = conn.execute(
            text("""
                INSERT INTO users (full_name, email, phone, password_hash)
                VALUES (:full_name, :email, :phone, :pw)
                RETURNING user_id, full_name, email, phone, primary_address_id
            """),
            {
                "full_name": data.full_name.strip(),
                "email": str(data.email).strip().lower(),
                "phone": data.phone.strip() if data.phone else None,
                "pw": data.password,
            },
        ).first()

    return {
        "user_id": as_uuid_str(row.user_id),
        "full_name": row.full_name,
        "email": row.email,
        "phone": row.phone,
        "primary_address_id": as_uuid_str(row.primary_address_id),
    }


@app.post("/auth/login", response_model=UserOut)
def login(data: LoginIn):
    with engine.connect() as conn:
        row = conn.execute(
            text("""
                SELECT user_id, full_name, email, phone, password_hash, primary_address_id
                FROM users
                WHERE email=:email
            """),
            {"email": str(data.email).strip().lower()},
        ).first()

    if (not row) or (row.password_hash != data.password):
        raise HTTPException(status_code=401, detail="Hatalı giriş")

    return {
        "user_id": as_uuid_str(row.user_id),
        "full_name": row.full_name,
        "email": row.email,
        "phone": row.phone,
        "primary_address_id": as_uuid_str(row.primary_address_id),
    }


# =========================
# LOOKUPS
# =========================
@app.get("/lookups/countries")
def get_countries(limit: int = 300):
    with engine.connect() as conn:
        rows = conn.execute(
            text("SELECT country_id, name, country_code FROM countries ORDER BY name LIMIT :limit"),
            {"limit": limit},
        ).mappings().all()
    return rows


@app.get("/lookups/cities")
def get_cities(country_id: str = Query(...), limit: int = 5000):
    with engine.connect() as conn:
        rows = conn.execute(
            text("""
                SELECT city_id, country_id, name
                FROM cities
                WHERE country_id=:country_id
                ORDER BY name
                LIMIT :limit
            """),
            {"country_id": country_id, "limit": limit},
        ).mappings().all()
    return rows


@app.get("/lookups/districts")
def get_districts(city_id: str = Query(...), limit: int = 20000):
    with engine.connect() as conn:
        rows = conn.execute(
            text("""
                SELECT district_id, city_id, name
                FROM districts
                WHERE city_id=:city_id
                ORDER BY name
                LIMIT :limit
            """),
            {"city_id": city_id, "limit": limit},
        ).mappings().all()
    return rows


@app.get("/lookups/neighborhoods")
def get_neighborhoods(district_id: str = Query(...), limit: int = 20000):
    with engine.connect() as conn:
        rows = conn.execute(
            text("""
                SELECT neighborhood_id, district_id, name
                FROM neighborhoods
                WHERE district_id=:district_id
                ORDER BY name
                LIMIT :limit
            """),
            {"district_id": district_id, "limit": limit},
        ).mappings().all()
    return rows


@app.get("/lookups/species")
def get_species(limit: int = 200):
    with engine.connect() as conn:
        rows = conn.execute(
            text("SELECT species_id, name FROM species ORDER BY name LIMIT :limit"),
            {"limit": limit},
        ).mappings().all()
    return rows


@app.get("/lookups/colors")
def get_colors(limit: int = 500):
    with engine.connect() as conn:
        rows = conn.execute(
            text("SELECT color_id, name FROM colors ORDER BY name LIMIT :limit"),
            {"limit": limit},
        ).mappings().all()
    return rows


# =========================
# ADDRESSES
# =========================
class AddressCreate(BaseModel):
    user_id: str
    country_id: str
    city_id: str
    district_id: str
    neighborhood_id: str
    address_label: str
    street: Optional[str] = None
    building_no: Optional[str] = None
    apartment_no: Optional[str] = None
    postal_code: Optional[str] = None
    is_default: bool = False


@app.post("/addresses")
def create_address(data: AddressCreate):
    with engine.begin() as conn:
        row = conn.execute(
            text("""
                INSERT INTO addresses (
                  country_id, city_id, district_id, neighborhood_id,
                  address_label, street, building_no, apartment_no, postal_code
                )
                VALUES (
                  :country_id, :city_id, :district_id, :neighborhood_id,
                  :address_label, :street, :building_no, :apartment_no, :postal_code
                )
                RETURNING address_id
            """),
            {
                "country_id": data.country_id,
                "city_id": data.city_id,
                "district_id": data.district_id,
                "neighborhood_id": data.neighborhood_id,
                "address_label": data.address_label.strip(),
                "street": data.street.strip() if data.street else None,
                "building_no": data.building_no.strip() if data.building_no else None,
                "apartment_no": data.apartment_no.strip() if data.apartment_no else None,
                "postal_code": data.postal_code.strip() if data.postal_code else None,
            },
        ).first()

        address_id = as_uuid_str(row.address_id)

        conn.execute(
            text("""
                INSERT INTO user_addresses (user_id, address_id, is_default)
                VALUES (:user_id, :address_id, :is_default)
                ON CONFLICT (user_id, address_id) DO NOTHING
            """),
            {"user_id": data.user_id, "address_id": address_id, "is_default": data.is_default},
        )

        if data.is_default:
            conn.execute(
                text("""
                    UPDATE users
                    SET primary_address_id = :address_id, updated_at = now()
                    WHERE user_id = :user_id
                """),
                {"address_id": address_id, "user_id": data.user_id},
            )

    return {"address_id": address_id}


@app.get("/users/{user_id}/addresses")
def list_user_addresses(user_id: str):
    with engine.connect() as conn:
        rows = conn.execute(
            text("""
                SELECT
                  a.address_id, a.country_id, a.city_id, a.district_id, a.neighborhood_id,
                  a.address_label, a.street, a.building_no, a.apartment_no, a.postal_code,
                  ua.is_default,
                  a.created_at, a.updated_at
                FROM user_addresses ua
                JOIN addresses a ON a.address_id = ua.address_id
                WHERE ua.user_id = :user_id
                ORDER BY ua.is_default DESC, a.created_at DESC
            """),
            {"user_id": user_id},
        ).mappings().all()

    out = []
    for r in rows:
        out.append({
            "address_id": as_uuid_str(r["address_id"]),
            "country_id": r["country_id"],
            "city_id": r["city_id"],
            "district_id": r["district_id"],
            "neighborhood_id": r["neighborhood_id"],
            "address_label": r["address_label"],
            "street": r["street"],
            "building_no": r["building_no"],
            "apartment_no": r["apartment_no"],
            "postal_code": r["postal_code"],
            "is_default": bool(r["is_default"]),
            "created_at": r["created_at"],
            "updated_at": r["updated_at"],
        })
    return out


class SetPrimaryAddressIn(BaseModel):
    user_id: str
    address_id: str


@app.post("/users/primary-address")
def set_primary_address(data: SetPrimaryAddressIn):
    with engine.begin() as conn:
        conn.execute(
            text("""
                UPDATE users
                SET primary_address_id=:address_id, updated_at=now()
                WHERE user_id=:user_id
            """),
            {"user_id": data.user_id, "address_id": data.address_id},
        )
    return {"ok": True}


@app.delete("/users/{user_id}/addresses/{address_id}")
def delete_user_address(user_id: str, address_id: str):
    with engine.begin() as conn:
        conn.execute(
            text("""
                DELETE FROM user_addresses
                WHERE user_id=:user_id AND address_id=:address_id
            """),
            {"user_id": user_id, "address_id": address_id},
        )

        still_used = conn.execute(
            text("SELECT 1 FROM user_addresses WHERE address_id=:address_id"),
            {"address_id": address_id},
        ).first()

        if not still_used:
            conn.execute(
                text("DELETE FROM addresses WHERE address_id=:address_id"),
                {"address_id": address_id},
            )

        conn.execute(
            text("""
                UPDATE users
                SET primary_address_id=NULL, updated_at=now()
                WHERE user_id=:user_id AND primary_address_id=:address_id
            """),
            {"user_id": user_id, "address_id": address_id},
        )

    return {"ok": True}


@app.get("/addresses/{address_id}")
def get_address(address_id: str):
    with engine.connect() as conn:
        row = conn.execute(
            text("""
                SELECT
                  a.address_id,
                  a.address_label,
                  a.street,
                  a.building_no,
                  a.apartment_no,
                  a.postal_code,
                  c.name  AS country_name,
                  ci.name AS city_name,
                  d.name  AS district_name,
                  n.name  AS neighborhood_name
                FROM addresses a
                JOIN countries c     ON c.country_id = a.country_id
                JOIN cities ci       ON ci.city_id = a.city_id
                JOIN districts d     ON d.district_id = a.district_id
                JOIN neighborhoods n ON n.neighborhood_id = a.neighborhood_id
                WHERE a.address_id = :address_id
            """),
            {"address_id": address_id},
        ).first()

    row = one_or_404(row, "Adres bulunamadı")

    return {
        "address_id": as_uuid_str(row.address_id),
        "label": row.address_label,
        "country": row.country_name,
        "city": row.city_name,
        "district": row.district_name,
        "neighborhood": row.neighborhood_name,
        "street": row.street,
        "building_no": row.building_no,
        "apartment_no": row.apartment_no,
        "postal_code": row.postal_code,
        "display_text": f"{row.neighborhood_name}, {row.district_name} / {row.city_name}",
    }


# =========================
# PETS
# =========================
class PetCreate(BaseModel):
    owner_user_id: str
    species_id: str
    name: Optional[str] = None
    sex: str = "bilinmiyor"
    age_years: Optional[int] = None
    microchip_no: Optional[str] = None
    distinctive_marks: Optional[str] = None
    color_ids: List[str] = Field(default_factory=list)


@app.post("/pets")
def create_pet(data: PetCreate):
    with engine.begin() as conn:
        row = conn.execute(
            text("""
                INSERT INTO pets
                  (owner_user_id, species_id, name, sex, age_years, microchip_no, distinctive_marks)
                VALUES
                  (:owner_user_id, :species_id, :name, :sex, :age_years, :microchip_no, :distinctive_marks)
                RETURNING pet_id
            """),
            {
                "owner_user_id": data.owner_user_id,
                "species_id": data.species_id,
                "name": data.name.strip() if data.name else None,
                "sex": data.sex,
                "age_years": data.age_years,
                "microchip_no": data.microchip_no.strip() if data.microchip_no else None,
                "distinctive_marks": data.distinctive_marks.strip() if data.distinctive_marks else None,
            },
        ).first()

        pet_id = as_uuid_str(row.pet_id)

        if data.color_ids:
            conn.execute(
                text("""
                    INSERT INTO pet_colors (pet_id, color_id)
                    SELECT :pet_id, x
                    FROM unnest(CAST(:color_ids AS text[])) AS x
                    ON CONFLICT (pet_id, color_id) DO NOTHING
                """),
                {"pet_id": pet_id, "color_ids": data.color_ids},
            )

    return {"pet_id": pet_id}


@app.get("/users/{user_id}/pets")
def list_user_pets(user_id: str):
    with engine.connect() as conn:
        pets_rows = conn.execute(
            text("""
                SELECT pet_id, owner_user_id, species_id, name, sex, age_years, microchip_no, distinctive_marks, created_at, updated_at
                FROM pets
                WHERE owner_user_id=:user_id
                ORDER BY created_at DESC
            """),
            {"user_id": user_id},
        ).mappings().all()

        pet_ids = [str(r["pet_id"]) for r in pets_rows]
        colors_map: Dict[str, List[str]] = {pid: [] for pid in pet_ids}

        if pet_ids:
            color_rows = conn.execute(
                text("""
                    SELECT pc.pet_id::text AS pet_id, pc.color_id
                    FROM pet_colors pc
                    WHERE pc.pet_id = ANY(CAST(:pet_ids AS uuid[]))
                """),
                {"pet_ids": pet_ids},
            ).mappings().all()

            for cr in color_rows:
                colors_map[cr["pet_id"]].append(cr["color_id"])

    out = []
    for r in pets_rows:
        pid = as_uuid_str(r["pet_id"])
        out.append({
            "pet_id": pid,
            "owner_user_id": as_uuid_str(r["owner_user_id"]),
            "species_id": r["species_id"],
            "name": r["name"],
            "sex": r["sex"],
            "age_years": r["age_years"],
            "microchip_no": r["microchip_no"],
            "distinctive_marks": r["distinctive_marks"],
            "color_ids": colors_map.get(pid, []),
            "created_at": r["created_at"],
            "updated_at": r["updated_at"],
        })
    return out


@app.delete("/pets/{pet_id}")
def delete_pet(pet_id: str):
    with engine.begin() as conn:
        conn.execute(text("DELETE FROM pet_colors WHERE pet_id=:pet_id"), {"pet_id": pet_id})
        conn.execute(text("DELETE FROM pets WHERE pet_id=:pet_id"), {"pet_id": pet_id})
    return {"ok": True}


# =========================
# LISTINGS + PHOTOS
# =========================
class ListingCreate(BaseModel):
    created_by: str
    pet_id: Optional[str] = None
    address_id: str
    listing_type: str
    status: str
    title: str
    description: Optional[str] = None
    event_time: Optional[str] = None
    species_id: Optional[str] = None


@app.post("/listings")
def create_listing(data: ListingCreate):
    # ✅ bulundu ilanında tür zorunlu (kendi kayıp ilanını match etme + doğru filtre)
    if data.listing_type == "bulundu" and (not data.species_id or not data.species_id.strip()):
        raise HTTPException(status_code=400, detail="Bulundu ilanı için tür (species_id) seçmelisin.")

    with engine.begin() as conn:
        row = conn.execute(
            text("""
                INSERT INTO listings
                  (created_by, pet_id, address_id, listing_type, status, title, description, event_time, species_id)
                VALUES
                  (:created_by, :pet_id, :address_id, :listing_type, :status, :title, :description, :event_time, :species_id)
                RETURNING listing_id, created_by, pet_id, address_id, listing_type, status,
                          title, description, event_time, species_id, created_at, updated_at
            """),
            {
                "created_by": data.created_by,
                "pet_id": data.pet_id,
                "address_id": data.address_id,
                "listing_type": data.listing_type,
                "status": data.status,
                "title": data.title.strip(),
                "description": data.description.strip() if data.description else None,
                "event_time": data.event_time.strip() if data.event_time else None,
                "species_id": data.species_id,
            }
        ).mappings().first()

    return {
        "listing_id": as_uuid_str(row["listing_id"]),
        "created_by": as_uuid_str(row["created_by"]),
        "pet_id": as_uuid_str(row["pet_id"]),
        "address_id": as_uuid_str(row["address_id"]),
        "listing_type": row["listing_type"],
        "status": row["status"],
        "title": row["title"],
        "description": row["description"],
        "event_time": row["event_time"],
        "species_id": row["species_id"],
        "created_at": row["created_at"],
        "updated_at": row["updated_at"],
    }


@app.get("/listings")
def list_listings(
    q: Optional[str] = None,
    listing_type: Optional[str] = None,
    status: Optional[str] = None,
    species_id: Optional[str] = None,
    limit: int = 50,
    offset: int = 0,
):
    sql = """
      SELECT
        l.listing_id, l.created_by, l.pet_id, l.address_id, l.listing_type, l.status,
        l.title, l.description, l.event_time, l.species_id, l.created_at, l.updated_at,

        c.name  AS city_name,
        d.name  AS district_name,
        n.name  AS neighborhood_name

      FROM listings l
      JOIN addresses a ON a.address_id = l.address_id
      JOIN cities c ON c.city_id = a.city_id
      JOIN districts d ON d.district_id = a.district_id
      JOIN neighborhoods n ON n.neighborhood_id = a.neighborhood_id
      WHERE 1=1
    """
    params: Dict[str, Any] = {"limit": limit, "offset": offset}

    if q:
        sql += " AND (l.title ILIKE :q OR l.description ILIKE :q)"
        params["q"] = f"%{q}%"
    if listing_type:
        sql += " AND l.listing_type = :listing_type"
        params["listing_type"] = listing_type
    if status:
        sql += " AND l.status = :status"
        params["status"] = status
    if species_id:
        sql += " AND l.species_id = :species_id"
        params["species_id"] = species_id

    sql += " ORDER BY l.created_at DESC LIMIT :limit OFFSET :offset"

    with engine.connect() as conn:
        rows = conn.execute(text(sql), params).mappings().all()

    out = []
    for r in rows:
        out.append({
            "listing_id": as_uuid_str(r["listing_id"]),
            "created_by": as_uuid_str(r["created_by"]),
            "pet_id": as_uuid_str(r["pet_id"]),
            "address_id": as_uuid_str(r["address_id"]),
            "listing_type": r["listing_type"],
            "status": r["status"],
            "title": r["title"],
            "description": r["description"],
            "event_time": r["event_time"],
            "created_at": r["created_at"],
            "updated_at": r["updated_at"],
            "species_id": r["species_id"],

            # ✅ keşfet konum alanları
            "city_name": r["city_name"],
            "district_name": r["district_name"],
            "neighborhood_name": r["neighborhood_name"],
            "location_text": f'{r["neighborhood_name"]}, {r["district_name"]} / {r["city_name"]}',
        })
    return out


class ListingStatusPatch(BaseModel):
    status: str


@app.patch("/listings/{listing_id}")
def patch_listing_status(listing_id: str, data: ListingStatusPatch):
    with engine.begin() as conn:
        conn.execute(
            text("""
                UPDATE listings
                SET status=:status, updated_at=now()
                WHERE listing_id=:listing_id
            """),
            {"status": data.status, "listing_id": listing_id},
        )
    return {"ok": True}


@app.delete("/listings/{listing_id}")
def delete_listing(listing_id: str):
    with engine.begin() as conn:
        conn.execute(text("DELETE FROM listing_photos WHERE listing_id=:listing_id"), {"listing_id": listing_id})
        conn.execute(text("DELETE FROM conversations WHERE listing_id=:listing_id"), {"listing_id": listing_id})
        conn.execute(text("DELETE FROM listings WHERE listing_id=:listing_id"), {"listing_id": listing_id})
    return {"ok": True}


class PhotoCreate(BaseModel):
    listing_id: str
    file_name: Optional[str] = None
    data_url: str
    sort_order: int = 0


@app.post("/listing-photos")
def add_photo(data: PhotoCreate):
    if not data.data_url.startswith("data:image/"):
        raise HTTPException(status_code=400, detail="data_url 'data:image/...;base64,...' ile başlamalı")

    with engine.begin() as conn:
        row = conn.execute(
            text("""
                INSERT INTO listing_photos (listing_id, file_name, data_url, sort_order)
                VALUES (:listing_id, :file_name, :data_url, :sort_order)
                RETURNING photo_id, listing_id, file_name, sort_order, created_at
            """),
            {
                "listing_id": data.listing_id,
                "file_name": data.file_name,
                "data_url": data.data_url,
                "sort_order": data.sort_order,
            }
        ).mappings().first()

    return {
        "photo_id": as_uuid_str(row["photo_id"]),
        "listing_id": as_uuid_str(row["listing_id"]),
        "file_name": row["file_name"],
        "sort_order": row["sort_order"],
        "created_at": row["created_at"],
    }


@app.get("/listings/{listing_id}/photos")
def list_listing_photos(listing_id: str, include_data_url: bool = True):
    with engine.connect() as conn:
        rows = conn.execute(
            text("""
                SELECT photo_id, listing_id, file_name, data_url, sort_order, created_at
                FROM listing_photos
                WHERE listing_id=:listing_id
                ORDER BY sort_order ASC, created_at ASC
            """),
            {"listing_id": listing_id},
        ).mappings().all()

    out = []
    for r in rows:
        obj = {
            "photo_id": as_uuid_str(r["photo_id"]),
            "listing_id": as_uuid_str(r["listing_id"]),
            "file_name": r["file_name"],
            "sort_order": r["sort_order"],
            "created_at": r["created_at"],
        }
        if include_data_url:
            obj["data_url"] = r["data_url"]
        out.append(obj)
    return out


@app.get("/listing-photos/{photo_id}")
def get_photo(photo_id: str):
    with engine.connect() as conn:
        row = conn.execute(
            text("""
                SELECT photo_id, listing_id, file_name, data_url, sort_order, created_at
                FROM listing_photos
                WHERE photo_id=:photo_id
            """),
            {"photo_id": photo_id},
        ).mappings().first()

    row = one_or_404(row, "Foto bulunamadı")
    return {
        "photo_id": as_uuid_str(row["photo_id"]),
        "listing_id": as_uuid_str(row["listing_id"]),
        "file_name": row["file_name"],
        "data_url": row["data_url"],
        "sort_order": row["sort_order"],
        "created_at": row["created_at"],
    }


@app.get("/listings/{listing_id}")
def get_listing_with_photos(listing_id: str):
    with engine.connect() as conn:
        l = conn.execute(
            text("""
                SELECT listing_id, created_by, pet_id, address_id, listing_type, status,
                       title, description, event_time, species_id, created_at, updated_at
                FROM listings
                WHERE listing_id=:listing_id
            """),
            {"listing_id": listing_id},
        ).mappings().first()

        l = one_or_404(l, "İlan bulunamadı")

        photos = conn.execute(
            text("""
                SELECT photo_id, file_name, data_url, sort_order, created_at
                FROM listing_photos
                WHERE listing_id=:listing_id
                ORDER BY sort_order ASC, created_at ASC
            """),
            {"listing_id": listing_id},
        ).mappings().all()

    return {
        "listing": {
            "listing_id": as_uuid_str(l["listing_id"]),
            "created_by": as_uuid_str(l["created_by"]),
            "pet_id": as_uuid_str(l["pet_id"]),
            "address_id": as_uuid_str(l["address_id"]),
            "listing_type": l["listing_type"],
            "status": l["status"],
            "title": l["title"],
            "description": l["description"],
            "event_time": l["event_time"],
            "species_id": l["species_id"],
            "created_at": l["created_at"],
            "updated_at": l["updated_at"],
        },
        "photos": [
            {
                "photo_id": as_uuid_str(p["photo_id"]),
                "file_name": p["file_name"],
                "data_url": p["data_url"],
                "sort_order": p["sort_order"],
                "created_at": p["created_at"],
            }
            for p in photos
        ],
    }


# =========================
# CONVERSATIONS / MESSAGES
# =========================
class OpenConversationIn(BaseModel):
    listing_id: str
    user_a: str
    user_b: str


@app.post("/conversations/open")
def open_or_create_conversation(data: OpenConversationIn):
    ua = data.user_a
    ub = data.user_b
    if ua == ub:
        raise HTTPException(status_code=400, detail="Aynı kullanıcılarla konuşma açılamaz")

    with engine.begin() as conn:
        existing = conn.execute(
            text("""
                SELECT c.conversation_id
                FROM conversations c
                JOIN conversation_participants p1 ON p1.conversation_id = c.conversation_id AND p1.user_id = :ua
                JOIN conversation_participants p2 ON p2.conversation_id = c.conversation_id AND p2.user_id = :ub
                WHERE c.listing_id = :listing_id
                LIMIT 1
            """),
            {"ua": ua, "ub": ub, "listing_id": data.listing_id},
        ).first()

        if existing:
            return {"conversation_id": as_uuid_str(existing.conversation_id), "created": False}

        row = conn.execute(
            text("""
                INSERT INTO conversations (listing_id)
                VALUES (:listing_id)
                RETURNING conversation_id, created_at
            """),
            {"listing_id": data.listing_id},
        ).first()

        cid = as_uuid_str(row.conversation_id)

        conn.execute(
            text("""
                INSERT INTO conversation_participants (conversation_id, user_id, role)
                VALUES
                  (:cid, :ua, 'participant'),
                  (:cid, :ub, 'participant')
            """),
            {"cid": cid, "ua": ua, "ub": ub},
        )

    return {"conversation_id": cid, "created": True}


@app.get("/users/{user_id}/conversations")
def list_user_conversations(user_id: str, limit: int = 100):
    with engine.connect() as conn:
        rows = conn.execute(
            text("""
                SELECT c.conversation_id, c.listing_id, c.created_at
                FROM conversation_participants cp
                JOIN conversations c ON c.conversation_id = cp.conversation_id
                WHERE cp.user_id = :user_id
                ORDER BY c.created_at DESC
                LIMIT :limit
            """),
            {"user_id": user_id, "limit": limit},
        ).mappings().all()
    return [
        {
            "conversation_id": as_uuid_str(r["conversation_id"]),
            "listing_id": as_uuid_str(r["listing_id"]),
            "created_at": r["created_at"],
        }
        for r in rows
    ]


@app.get("/conversations/{conversation_id}/participants")
def list_conversation_participants(conversation_id: str):
    with engine.connect() as conn:
        rows = conn.execute(
            text("""
                SELECT conversation_id, user_id, role, created_at
                FROM conversation_participants
                WHERE conversation_id=:conversation_id
                ORDER BY created_at ASC
            """),
            {"conversation_id": conversation_id},
        ).mappings().all()

    return [
        {
            "conversation_id": as_uuid_str(r["conversation_id"]),
            "user_id": as_uuid_str(r["user_id"]),
            "role": r["role"],
            "created_at": r["created_at"],
        }
        for r in rows
    ]


class SendMessageIn(BaseModel):
    conversation_id: str
    sender_user_id: str
    body: str


@app.post("/messages")
def send_message(data: SendMessageIn):
    body = data.body.strip()
    if not body:
        raise HTTPException(status_code=400, detail="Mesaj boş olamaz")

    with engine.begin() as conn:
        row = conn.execute(
            text("""
                INSERT INTO messages (conversation_id, sender_user_id, body)
                VALUES (:conversation_id, :sender_user_id, :body)
                RETURNING message_id, conversation_id, sender_user_id, body, created_at
            """),
            {
                "conversation_id": data.conversation_id,
                "sender_user_id": data.sender_user_id,
                "body": body,
            },
        ).mappings().first()

    return {
        "message_id": as_uuid_str(row["message_id"]),
        "conversation_id": as_uuid_str(row["conversation_id"]),
        "sender_user_id": as_uuid_str(row["sender_user_id"]),
        "body": row["body"],
        "created_at": row["created_at"],
    }


@app.get("/conversations/{conversation_id}/messages")
def list_messages(conversation_id: str, limit: int = 300):
    with engine.connect() as conn:
        rows = conn.execute(
            text("""
                SELECT message_id, conversation_id, sender_user_id, body, created_at
                FROM messages
                WHERE conversation_id=:conversation_id
                ORDER BY created_at ASC
                LIMIT :limit
            """),
            {"conversation_id": conversation_id, "limit": limit},
        ).mappings().all()

    return [
        {
            "message_id": as_uuid_str(r["message_id"]),
            "conversation_id": as_uuid_str(r["conversation_id"]),
            "sender_user_id": as_uuid_str(r["sender_user_id"]),
            "body": r["body"],
            "created_at": r["created_at"],
        }
        for r in rows
    ]
############
#  Matches  #
############


from fastapi import Path, Query

@app.get("/matches/{lost_listing_id}")
def get_matches_by_path(
    lost_listing_id: str = Path(...),
    limit: int = 60,
    offset: int = 0
):
    with engine.begin() as conn:
        # 1) Lost ilan bilgilerini çek (species NULL ise pet'ten al)
        lo = conn.execute(
            text("""
                SELECT
                  l.listing_id::text AS lost_listing_id,
                  l.created_by::text AS lo_created_by,
                  COALESCE(NULLIF(trim(l.species_id), ''), p.species_id) AS lo_species_id,
                  l.pet_id::text     AS lo_pet_id,
                  a.city_id          AS lo_city_id,
                  a.district_id      AS lo_district_id,
                  a.neighborhood_id  AS lo_neighborhood_id
                FROM listings l
                JOIN addresses a ON a.address_id = l.address_id
                LEFT JOIN pets p ON p.pet_id = l.pet_id
                WHERE l.listing_id = CAST(:lost_listing_id AS uuid)
                  AND lower(trim(l.listing_type)) IN ('kayıp','kayip')
                  AND lower(trim(l.status)) = 'aktif'
            """),
            {"lost_listing_id": lost_listing_id},
        ).mappings().first()

        if not lo:
            return []

        if not lo["lo_species_id"]:
            return []

        # 2) Match hesapla + listing_matches'e upsert et
        conn.execute(
            text("""
                WITH candidates AS (
                    SELECT
                        f.listing_id AS found_listing_id,
                        f.created_by AS found_created_by,
                        f.pet_id     AS found_pet_id,
                        f.title      AS found_title,
                        f.description AS found_description,
                        f.event_time AS found_event_time,
                        f.created_at AS found_created_at,
                        fa.city_id,
                        fa.district_id,
                        fa.neighborhood_id,
                        COALESCE(NULLIF(trim(f.species_id), ''), fp.species_id) AS found_species_effective
                    FROM listings f
                    JOIN addresses fa ON fa.address_id = f.address_id
                    LEFT JOIN pets fp ON fp.pet_id = f.pet_id
                    WHERE lower(trim(f.listing_type)) = 'bulundu'
                      AND lower(trim(f.status)) = 'aktif'
                      AND COALESCE(NULLIF(trim(f.species_id), ''), fp.species_id) = :lo_species_id
                      AND fa.city_id   = :lo_city_id
                      AND f.created_by <> CAST(:lo_created_by AS uuid)
                      AND f.listing_id <> CAST(:lost_listing_id AS uuid)
                ),
                lo_pet AS (
                    SELECT p.sex
                    FROM pets p
                    WHERE p.pet_id = CAST(:lo_pet_id AS uuid)
                ),
                lo_colors AS (
                    SELECT color_id
                    FROM pet_colors
                    WHERE pet_id = CAST(:lo_pet_id AS uuid)
                ),
                scored AS (
                    SELECT
                        CAST(:lost_listing_id AS uuid) AS lost_listing_id,
                        c.found_listing_id,

                        (c.district_id = :lo_district_id) AS district_match,
                        (c.neighborhood_id = :lo_neighborhood_id) AS neighborhood_match,

                        CASE
                          WHEN :lo_pet_id IS NULL OR c.found_pet_id IS NULL THEN FALSE
                          WHEN (SELECT sex FROM lo_pet) IS NULL THEN FALSE
                          ELSE (
                            SELECT (fp2.sex = (SELECT sex FROM lo_pet))
                            FROM pets fp2
                            WHERE fp2.pet_id = c.found_pet_id
                          )
                        END AS sex_match,

                        COALESCE((
                          SELECT COUNT(DISTINCT lc.color_id)
                          FROM lo_colors lc
                          JOIN pet_colors fc
                            ON fc.pet_id = c.found_pet_id AND fc.color_id = lc.color_id
                        ), 0) AS shared_color_count
                    FROM candidates c
                ),
                final_rows AS (
                    SELECT
                        lost_listing_id,
                        found_listing_id,
                        (
                          50
                          + CASE WHEN neighborhood_match THEN 25 ELSE 0 END
                          + CASE WHEN district_match THEN 15 ELSE 0 END
                          + CASE WHEN sex_match THEN 10 ELSE 0 END
                          + LEAST(shared_color_count, 5) * 3
                        )::int AS score,
                        jsonb_build_object(
                          'species_match', TRUE,
                          'district_match', district_match,
                          'neighborhood_match', neighborhood_match,
                          'sex_match', sex_match,
                          'shared_color_count', shared_color_count
                        ) AS reasons
                    FROM scored
                )
                INSERT INTO listing_matches (lost_listing_id, found_listing_id, score, reasons)
                SELECT lost_listing_id, found_listing_id, score, reasons
                FROM final_rows
                ON CONFLICT (lost_listing_id, found_listing_id)
                DO UPDATE
                  SET score = EXCLUDED.score,
                      reasons = EXCLUDED.reasons,
                      created_at = now();
            """),
            {
                "lost_listing_id": lost_listing_id,
                "lo_created_by": lo["lo_created_by"],
                "lo_species_id": lo["lo_species_id"],
                "lo_city_id": lo["lo_city_id"],
                "lo_district_id": lo["lo_district_id"],
                "lo_neighborhood_id": lo["lo_neighborhood_id"],
                "lo_pet_id": lo["lo_pet_id"],
            },
        )

        # 3) Frontend'e dönecek liste
        rows = conn.execute(
            text("""
                SELECT
                  lm.found_listing_id::text,
                  lm.score,
                  lm.reasons,

                  f.title AS found_title,
                  f.description AS found_description,
                  f.event_time AS found_event_time,
                  f.created_at AS found_created_at,

                  c.name AS found_city_name,
                  d.name AS found_district_name,
                  n.name AS found_neighborhood_name
                FROM listing_matches lm
                JOIN listings f ON f.listing_id = lm.found_listing_id
                JOIN addresses a ON a.address_id = f.address_id
                JOIN cities c ON c.city_id = a.city_id
                JOIN districts d ON d.district_id = a.district_id
                JOIN neighborhoods n ON n.neighborhood_id = a.neighborhood_id
                WHERE lm.lost_listing_id = CAST(:lost_listing_id AS uuid)
                ORDER BY lm.score DESC, f.created_at DESC
                LIMIT :limit OFFSET :offset
            """),
            {"lost_listing_id": lost_listing_id, "limit": limit, "offset": offset},
        ).mappings().all()

    return rows


@app.get("/matches")
def get_matches_query(lost_listing_id: str = Query(...), limit: int = 60, offset: int = 0):
    return get_matches_by_path(lost_listing_id=lost_listing_id, limit=limit, offset=offset)


